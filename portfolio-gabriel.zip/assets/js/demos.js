(function(){
const q=(r,s)=>r.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const T=f=>window.__addTimer(f);
const wait=ms=>new Promise(r=>T(setTimeout(r,reduce?0:ms)));
const norm=s=>s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');
const el=html=>{const t=document.createElement('template');t.innerHTML=html.trim();return t.content.firstChild;};
const hash=s=>{let h=0;for(const c of s)h=(h*31+c.charCodeAt(0))>>>0;return h;};
const pad=n=>String(n).padStart(2,'0');
const brl=v=>'R$ '+v.toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});
const today=()=>{const d=new Date();return {d:pad(d.getDate())+'/'+pad(d.getMonth()+1)+'/'+d.getFullYear(),ymd:d.getFullYear()+pad(d.getMonth()+1)+pad(d.getDate())};};
const COLS='ABCDEFGHIJ';
function gaugeSVG(v,color){const a=Math.PI*(1-v/100);const x=90+70*Math.cos(a),y=90-70*Math.sin(a);return '<svg viewBox="0 0 180 100" aria-hidden="true"><path d="M20 90 A70 70 0 0 1 160 90" fill="none" stroke="var(--line)" stroke-width="14" stroke-linecap="round"/><path d="M20 90 A70 70 0 0 1 '+x.toFixed(1)+' '+y.toFixed(1)+'" fill="none" stroke="'+color+'" stroke-width="14" stroke-linecap="round"/></svg>';}
function chrome(url,dark){return '<div class="chrome"><div class="dots"><i></i><i></i><i></i></div><div class="url">'+esc(url)+'</div></div>';}

/* ---------- Google Sheets mock ---------- */
function makeSheet(host,{file,menu,items}){
  const app=el('<div class="app"><div class="sh-title"><span class="ico"></span><b>'+esc(file)+'</b></div><div class="sh-menu"><span>Arquivo</span><span>Editar</span><span>Ver</span><span>Inserir</span><span>Formatar</span><span>Dados</span><span>Extensões</span><button class="custom" aria-expanded="false">'+esc(menu)+' ▾</button></div><div class="sh-fx"><i>fx</i><span class="fxv"></span></div><div class="sh-grid"></div><div class="sh-tabs"></div></div>');
  host.appendChild(app);
  const mb=q(app,'.custom');let dd=null;
  const closeDD=()=>{if(dd){dd.remove();dd=null;mb.setAttribute('aria-expanded','false');}};
  mb.onclick=e=>{e.stopPropagation();if(dd){closeDD();return;}dd=el('<div class="dd"></div>');items.forEach(([t,fn])=>{const b=el('<button>'+esc(t)+'</button>');b.onclick=()=>{closeDD();fn();};dd.appendChild(b);});dd.style.left=mb.offsetLeft+'px';q(app,'.sh-menu').appendChild(dd);mb.setAttribute('aria-expanded','true');};
  app.addEventListener('click',e=>{if(dd&&!dd.contains(e.target))closeDD();});
  const api={app,
    grid:q(app,'.sh-grid'),
    render(rows,{minRows=10,editCol=-1,cls=()=>'' ,onEdit}={}){
      const nc=Math.max(...rows.map(r=>r.length),1)+1;const nr=Math.max(rows.length,minRows);
      let h='<table><thead><tr><th></th>'+[...Array(nc)].map((_,i)=>'<th>'+COLS[i]+'</th>').join('')+'</tr></thead><tbody>';
      for(let r=0;r<nr;r++){h+='<tr class="'+(r===0?'h':'')+'"><td class="rn">'+(r+1)+'</td>';for(let c=0;c<nc;c++){const v=(rows[r]||[])[c];h+='<td data-r="'+r+'" data-c="'+c+'" class="'+cls(r,c,v)+'"'+(r>0&&c===editCol&&r<rows.length?' contenteditable="true"':'')+'>'+(v==null?'':esc(v))+'</td>';}h+='</tr>';}
      api.grid.innerHTML=h+'</tbody></table>';
      api.grid.querySelectorAll('td[data-r]').forEach(td=>td.addEventListener('focus',()=>{q(app,'.fxv').textContent=td.textContent;}));
      api.grid.querySelectorAll('td[contenteditable]').forEach(td=>td.addEventListener('input',()=>{q(app,'.fxv').textContent=td.textContent;onEdit&&onEdit(+td.dataset.r,td.textContent);}));
      api.grid.querySelectorAll('td[data-r]').forEach(td=>td.addEventListener('click',()=>{q(app,'.fxv').textContent=td.textContent;}));
    },
    cell(r,c){return api.grid.querySelector('td[data-r="'+r+'"][data-c="'+c+'"]');},
    tabs(names,active,onSel){const t=q(app,'.sh-tabs');t.innerHTML='';names.forEach(n=>{const b=el('<button role="tab" aria-selected="'+(n===active)+'">'+esc(n)+'</button>');b.onclick=()=>onSel(n);t.appendChild(b);});},
    dialog(inner){const d=el('<div class="gdlg"><div class="box">'+inner+'</div></div>');app.appendChild(d);return d;},
    alert(text,title){return new Promise(res=>{const d=api.dialog((title?'<h5>'+esc(title)+'</h5>':'')+'<p>'+esc(text)+'</p><div class="acts"><button class="pri">OK</button></div>');const b=q(d,'button');b.focus();b.onclick=()=>{d.remove();res();};});},
    prompt(title,text){return new Promise(res=>{const d=api.dialog('<h5>'+esc(title)+'</h5><p>'+esc(text)+'</p><input type="text" aria-label="'+esc(text)+'"><div class="acts"><button data-a="c">Cancelar</button><button class="pri" data-a="ok">OK</button></div>');const i=q(d,'input');i.focus();const done=v=>{d.remove();res(v);};q(d,'[data-a=ok]').onclick=()=>done(i.value);q(d,'[data-a=c]').onclick=()=>done(null);i.onkeydown=e=>{if(e.key==='Enter')done(i.value);};});},
    toast(t){const x=el('<div class="toast">'+esc(t)+'</div>');app.appendChild(x);T(setTimeout(()=>x.remove(),2200));}
  };
  return api;
}
function termLog(t){return (txt,cls)=>{t.insertAdjacentHTML('beforeend','<div'+(cls?' class="'+cls+'"':'')+'>'+txt+'</div>');t.scrollTop=1e9;};}

const DEMOS={};window.DEMOS=DEMOS;

/* ================= SENTIMENTOS ================= */
const POSW=['otimo','excelente','bom','boa','adorei','gostei','rapido','rapida','facil','resolveu','parabens','amei','eficiente','atencioso','atenciosa','perfeito','recomendo','satisfeito','ajudou','incrivel','agil'];
const NEGW=['ruim','pessimo','demora','demorou','lento','lenta','erro','problema','nao funciona','travou','caro','cancelar','insatisfeito','reclamacao','dificil','confuso','falha','sem resposta','horrivel','bug'];
const STOP=['para','pela','pelo','muito','mais','como','hoje','todos','dias','duas','vezes','esse','essa','isso','seria','teria','minha','meu','tive','três','tres','apenas','sobre','quando','ainda','também','tambem','porque','estou','foram','sistema'];
function sentiment(t){
  const n=norm(t);let p=0,qn=0;const hp=[];
  POSW.forEach(w=>{if(n.includes(w)){p++;hp.push(w);}});NEGW.forEach(w=>{if(n.includes(w)){qn++;hp.push(w);}});
  if(/\bnao\b.{0,12}(bom|gostei|resolveu|ajudou)/.test(n)){qn+=2;p=Math.max(0,p-1);}
  const s=p-qn;const label=s>0?'positivo':s<0?'negativo':'neutro';
  const conf=(Math.min(0.98,0.55+Math.abs(s)*0.14+(p+qn)*0.03)).toFixed(2);
  let cat='comentário';if(/sugest|poderia|seria bom|gostaria|ter um/.test(n))cat='sugestão';else if(label==='negativo')cat='reclamação';else if(label==='positivo')cat='elogio';
  const emo=label==='positivo'?'alegria':label==='negativo'?(/demor|lent|sem resposta/.test(n)?'frustração':'raiva'):'neutra';
  const words=t.toLowerCase().replace(/[^\p{L}\s]/gu,' ').split(/\s+/).filter(w=>w.length>=5&&!STOP.includes(w));
  const kws=[...new Set(words)].slice(0,3).join(',');
  return {label,conf,cat,emo,kws};
}
DEMOS.sentimento=d=>{
  const data=[['Resposta do Cliente'],['Atendimento excelente, resolveu meu problema rápido!'],['O sistema travou duas vezes hoje, muito ruim.'],['Seria bom ter um relatório de vendas por vendedor.'],['Gostei da plataforma, fácil de usar.'],['Demorou três dias para ter resposta, insatisfeito.'],['Uso todos os dias para responder clientes.']];
  let tab='Página1',hasResumo=false,running=false,summary=null;
  const wrapEl=el('<div class="d-col"></div>');d.appendChild(wrapEl);
  const sh=makeSheet(wrapEl,{file:'Feedbacks de clientes',menu:'✉️ Analisar Sentimentos',items:[['Iniciar Análise',()=>run()]]});
  const lg=el('<div class="term" style="height:120px" aria-label="Registro de execução"></div>');wrapEl.appendChild(lg);const log=termLog(lg);
  wrapEl.appendChild(el('<p class="hint">Clique numa célula da coluna A para editar a resposta. A classificação aqui é um léxico simples que devolve o mesmo formato que o prompt original pede ao Llama 3 (via Groq).</p>'));
  log('<span class="m">Apps Script · aguardando execução pelo menu ✉️ Analisar Sentimentos</span>');
  const cls=(r,c,v)=>c===1&&r>0?({positivo:'pos',negativo:'neg',neutro:'neu'}[v]||''):'';
  const draw=()=>{
    if(tab==='Página1')sh.render(data,{editCol:0,cls,onEdit:(r,t)=>{data[r][0]=t;}});
    else sh.render([['📊 Total de Feedbacks',summary.total],['✅ Positivos',summary.p],['⚠️ Negativos',summary.n],['➖ Neutros',summary.z],['💚 Taxa de Satisfação',summary.tx]],{minRows:8});
    sh.tabs(hasResumo?['Página1','Resumo Sentimentos']:['Página1'],tab,n=>{tab=n;draw();});
  };
  draw();
  async function run(){
    if(running)return;running=true;tab='Página1';
    const head=['Sentimento','Confiança','Categoria','Emoção','Palavras-chave'];
    head.forEach((h,i)=>data[0][i+1]=h);for(let r=1;r<data.length;r++)data[r].length=1;draw();
    log('<span class="y">▶ analisarSentimentos()</span>');
    let p=0,n=0,z=0;
    for(let r=1;r<data.length;r++){
      const txt=(data[r][0]||'').trim();if(!txt)continue;
      log('<span class="m">chamarIA(prompt) · llama3-8b-8192 · linha '+(r+1)+'</span>');
      await wait(420);
      const s=sentiment(txt);const raw=[s.label,s.conf,s.cat,s.emo,s.kws].join('|');
      log('← <span class="p">'+esc(raw)+'</span>');
      data[r]=[txt,...raw.split('|')];
      if(s.label==='positivo')p++;else if(s.label==='negativo')n++;else z++;
      draw();for(let c=1;c<=5;c++){const td=sh.cell(r,c);if(td){td.classList.add('new');}}
    }
    const total=p+n+z;summary={total,p,n,z,tx:total?((p/total)*100).toFixed(1)+'%':'0%'};hasResumo=true;draw();
    log('<span class="y">Resumo Sentimentos atualizado</span> · '+total+' feedbacks · satisfação '+summary.tx);
    await sh.alert('✅ Análise de sentimentos concluída com sucesso!');
    tab='Resumo Sentimentos';draw();running=false;
  }
};

/* ================= ASSISTENTE DE SCRIPTS ================= */
DEMOS.queries=d=>{
  const FILES=[
   ['mrr_por_plano.sql','Calcula quanto a empresa recebe por mês em assinaturas, separado por plano.'],
   ['clientes_sem_login_30d.sql','Lista os clientes que não entram no sistema há mais de 30 dias. Ajuda a agir antes do churn.'],
   ['tempo_primeira_resposta.sql','Mostra quanto tempo cada equipe de atendimento leva, em média, para responder o cliente pela primeira vez.'],
   ['funil_conversao.sql','Conta quantos negócios passaram por cada etapa do funil de vendas e a conversão entre elas.'],
   ['nps_por_segmento.sql','Calcula a nota de satisfação (NPS) separada por segmento de cliente.'],
   ['manual_processo.pdf',null],
   ['envia_relatorio_diario.py','Roda uma consulta no banco, salva em Excel e envia o relatório por e-mail em horários definidos.'],
   ['atualiza_status_crm.gs','Atualiza sozinho o status dos clientes na planilha a partir de outra aba.'],
   ['dashboard_metas.html','Página simples que mostra as metas do mês e quanto já foi atingido.'],
   ['rascunho.txt','']
  ];
  const cat=[];let tab='Página1',running=false,chatOpen=false;
  const box=el('<div class="d-col"></div>');d.appendChild(box);
  const sh=makeSheet(box,{file:'Catálogo de Scripts',menu:'🧠 Assistente de Scripts',items:[['🔄 Atualizar Catálogo',()=>update()],['💬 Abrir Chat com IA',()=>openChat()]]});
  const lg=el('<div class="term" style="height:120px"></div>');box.appendChild(lg);const log=termLog(lg);
  box.appendChild(el('<p class="hint">Pasta do Drive e descrições fictícias. No original, cada descrição vem do llama3-70b e o script espera 30 s entre chamadas para não estourar o rate limit (aqui é acelerado).</p>'));
  log('<span class="m">Pasta do Drive: 10 arquivos · use o menu 🧠 Assistente de Scripts</span>');
  const draw=()=>{if(tab==='Catalogo')sh.render([['Nome do Arquivo','Descrição do Script','Link','Data de Modificação'],...cat]);else sh.render([[]]);sh.tabs(cat.length?['Página1','Catalogo']:['Página1'],tab,n=>{tab=n;draw();});};
  draw();
  async function update(){
    if(running)return;running=true;tab='Catalogo';draw();let novos=0,atual=0;
    log('<span class="y">▶ catalogarScriptsComDescricaoGroq()</span>');
    for(const [nome,desc] of FILES){
      const ext=nome.slice(nome.lastIndexOf('.'));
      log('Arquivo: '+esc(nome)+' | Extensão: '+ext);
      if(desc===null){log('<span class="m">Ignorando arquivo não suportado: '+esc(nome)+'</span>');continue;}
      const ex=cat.find(r=>r[0]===nome);const dt=today().d;
      if(ex){ex[3]=dt;atual++;await wait(80);draw();continue;}
      await wait(380);
      const ds=desc===''?'Arquivo muito curto para análise':desc;
      if(desc!=='')log('<span class="p">gerarDescricaoGroq ✓</span> <span class="m">· Utilities.sleep(30000)</span>');
      cat.push([nome,ds,'drive.google.com/file/d/…/view',dt]);novos++;draw();
      const td=sh.cell(cat.length,1);if(td)td.classList.add('new');
    }
    await sh.alert('✅ Catálogo atualizado!\n\n🆕 Novos arquivos inseridos: '+novos+'\n♻️ Arquivos atualizados: '+atual);
    running=false;
  }
  function openChat(){
    if(chatOpen)return;chatOpen=true;
    const dl=sh.dialog('<h5>💬 Chat com IA sobre Scripts</h5><div class="cx" style="border:1px solid #ccc;padding:10px;height:150px;overflow-y:auto;margin-bottom:10px;font-size:13px"></div><div class="qr cq" style="margin-bottom:8px"></div><div style="display:flex;gap:6px"><input type="text" placeholder="Faça sua pergunta..." style="flex:1;border:1px solid #ccc;border-bottom:1px solid #ccc;padding:8px"><button class="pri" style="background:#1a73e8;color:#fff;border:0;border-radius:4px;padding:8px 12px">Enviar</button></div><div class="acts"><button data-a="x">Fechar</button></div>');
    q(dl,'.box').style.width='min(440px,100%)';
    const cx=q(dl,'.cx'),inp=q(dl,'input');
    ['tem algum script de churn?','qual script calcula o nps?','preciso de algo sobre funil de vendas','como envio relatório por e-mail?'].forEach(s=>{const b=el('<button style="background:#f1f3f4;border:1px solid #dadce0;color:#202124;border-radius:999px;padding:4px 10px;font-size:12px">'+s+'</button>');b.onclick=()=>{inp.value=s;send();};q(dl,'.cq').appendChild(b);});
    const add=(h,cls)=>{const m=el('<div style="margin:5px 0;white-space:pre-wrap;text-align:'+(cls==='u'?'right;color:blue':'left;color:green')+'">'+h+'</div>');cx.appendChild(m);cx.scrollTop=1e9;};
    const stop=['a','o','e','de','do','da','em','com','para','é','que','qual','quais','tem','sobre','alguma','algum'];
    async function send(){const v=inp.value.trim();if(!v)return;inp.value='';add(esc('Você: '+v),'u');await wait(650);
      if(!cat.length){add('<strong>IA:</strong><br>❌ Aba \'Catalogo\' não encontrada.');return;}
      const pal=v.toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(p=>p&&!stop.includes(p));
      const f=cat.filter(r=>pal.some(p=>r[0].toLowerCase().includes(p)||r[1].toLowerCase().includes(p)));
      if(!f.length){add('<strong>IA:</strong><br>⚠️ Nenhum script relacionado encontrado.');return;}
      add('<strong>IA:</strong><br>'+esc('Encontrei '+(f.length>1?'estes scripts relevantes':'este script relevante')+' para a sua pergunta:\n\n'+f.slice(0,4).map((r,i)=>(i+1)+'. '+r[0]+' — '+r[1]+'\n   Link: '+r[2]).join('\n')));}
    q(dl,'.pri').onclick=send;inp.onkeydown=e=>{if(e.key==='Enter')send();};inp.focus();
    q(dl,'[data-a=x]').onclick=()=>{dl.remove();chatOpen=false;};
  }
};

/* ================= CHAT IA (visual do repositório) ================= */
DEMOS.chat=d=>{
  const ui=el(`<div style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);border-radius:12px;padding:18px;font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif">
   <div style="max-width:560px;margin:0 auto;background:rgba(255,255,255,.95);border-radius:18px;overflow:hidden;box-shadow:0 20px 40px rgba(0,0,0,.2);display:flex;flex-direction:column;height:440px">
    <div style="background:linear-gradient(135deg,#4facfe 0%,#00f2fe 100%);color:#fff;padding:14px 16px;display:flex;justify-content:space-between;align-items:center">
     <div style="display:flex;gap:10px;align-items:center"><div style="width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,#ff6b6b,#ffa726);display:flex;align-items:center;justify-content:center;font-size:20px">🤖</div><div><b style="font-size:16px">AI Assistant - Groq</b><div style="font-size:12px;display:flex;align-items:center;gap:6px"><span style="width:8px;height:8px;border-radius:50%;background:#4ade80;display:inline-block"></span><span class="st">Online</span></div></div></div>
     <div style="display:flex;gap:6px"><button class="cl" title="Limpar Chat" aria-label="Limpar chat" style="background:rgba(255,255,255,.2);border:0;border-radius:50%;width:34px;height:34px;color:#fff">🗑</button><button class="ex" title="Exportar Chat" aria-label="Exportar chat" style="background:rgba(255,255,255,.2);border:0;border-radius:50%;width:34px;height:34px;color:#fff">⬇</button></div>
    </div>
    <div class="ms" style="flex:1;overflow-y:auto;padding:16px;background:#fafafa;display:flex;flex-direction:column;gap:12px;color:#1f2937"></div>
    <div style="padding:12px;background:#fff;border-top:1px solid #eee;display:flex;gap:8px;align-items:center"><input type="text" class="in" placeholder="Digite sua mensagem..." aria-label="Mensagem" style="flex:1;border:2px solid #e5e7eb;border-radius:22px;padding:10px 14px;background:#f8fafc;color:#1f2937;font-family:inherit"><button class="sd" aria-label="Enviar" style="width:42px;height:42px;border-radius:50%;border:0;background:linear-gradient(135deg,#4facfe 0%,#00f2fe 100%);color:#fff;font-size:16px">➤</button></div>
   </div></div>`);
  d.appendChild(ui);d.appendChild(el('<p class="hint" style="margin-top:10px">Visual reproduzido do index.html do repositório. Respostas roteirizadas: no original, o Flask envia a mensagem ao LLaMA 3 via Groq.</p>'));
  const ms=q(ui,'.ms'),inp=q(ui,'.in');let hist=[];
  const empty=()=>{ms.innerHTML='<div style="margin:auto;text-align:center;color:#9ca3af"><div style="font-size:40px">💬</div><h3 style="margin:6px 0 4px;color:#6b7280;font-family:inherit;font-size:18px">Comece uma conversa</h3><p style="margin:0;font-size:14px">Digite uma mensagem para começar a conversar com a IA</p><div class="sug" style="display:flex;gap:6px;flex-wrap:wrap;justify-content:center;margin-top:12px"></div></div>';
    ['O que é churn?','Como funciona o backend?','Me dê um exemplo de SQL'].forEach(s=>{const b=el('<button style="background:#fff;border:1px solid #e5e7eb;color:#374151;border-radius:999px;padding:5px 11px;font-size:12.5px">'+s+'</button>');b.onclick=()=>{inp.value=s;send();};q(ms,'.sug').appendChild(b);});};
  empty();
  const time=()=>{const n=new Date();return pad(n.getHours())+':'+pad(n.getMinutes());};
  const add=(t,me)=>{if(!hist.length)ms.innerHTML='';hist.push((me?'Você':'IA')+' ['+time()+']: '+t);
    ms.appendChild(el('<div style="display:flex;gap:8px;align-items:flex-end;'+(me?'flex-direction:row-reverse':'')+';animation:rowin .3s both"><div style="width:30px;height:30px;border-radius:50%;flex:none;display:flex;align-items:center;justify-content:center;font-size:14px;background:'+(me?'linear-gradient(135deg,#4facfe,#00f2fe)':'linear-gradient(135deg,#ff6b6b,#ffa726)')+'">'+(me?'🙂':'🤖')+'</div><div style="max-width:72%"><div style="padding:10px 14px;border-radius:16px;font-size:14px;line-height:1.45;white-space:pre-wrap;'+(me?'background:linear-gradient(135deg,#4facfe 0%,#00f2fe 100%);color:#fff;border-bottom-right-radius:4px':'background:#fff;border:1px solid #e5e7eb;border-bottom-left-radius:4px')+'">'+esc(t)+'</div><div style="font-size:11px;color:#9ca3af;margin-top:3px;text-align:'+(me?'right':'left')+'">'+time()+'</div></div></div>'));ms.scrollTop=1e9;};
  const reply=v=>{const n=norm(v);
    if(/^(oi|ola|bom dia|boa tarde|boa noite)/.test(n))return 'Olá! 👋 Como posso te ajudar hoje?';
    if(/churn/.test(n))return 'Churn é a taxa de clientes que cancelam em um período.\n\nUma forma simples de calcular: cancelados no mês ÷ clientes ativos no início do mês × 100.';
    if(/backend|flask|funciona/.test(n))return 'O front envia sua mensagem via fetch para a rota /chat do Flask. O Flask chama a API da Groq com o modelo LLaMA 3 e devolve a resposta em JSON, que aparece aqui.';
    if(/sql/.test(n))return 'Claro! Exemplo:\n\nSELECT cliente, SUM(valor) AS total\nFROM vendas\nGROUP BY cliente\nORDER BY total DESC;';
    if(/n8n|automa/.test(n))return 'n8n é uma ferramenta de automação por fluxos: cada nó é uma etapa (gatilho, consulta, transformação, envio).';
    return 'Boa pergunta! Nesta demonstração eu respondo sobre churn, SQL, n8n e como o projeto funciona.';};
  async function send(){const v=inp.value.trim();if(!v)return;inp.value='';add(v,true);q(ui,'.st').textContent='Digitando...';
    const ty=el('<div style="display:flex;gap:4px;padding:10px 14px;background:#fff;border:1px solid #e5e7eb;border-radius:16px;width:max-content"><span style="width:7px;height:7px;border-radius:50%;background:#9ca3af;animation:blink 1s infinite"></span><span style="width:7px;height:7px;border-radius:50%;background:#9ca3af;animation:blink 1s .2s infinite"></span><span style="width:7px;height:7px;border-radius:50%;background:#9ca3af;animation:blink 1s .4s infinite"></span></div>');ms.appendChild(ty);ms.scrollTop=1e9;
    await wait(800);ty.remove();add(reply(v));q(ui,'.st').textContent='Online';}
  q(ui,'.sd').onclick=send;inp.onkeydown=e=>{if(e.key==='Enter')send();};
  q(ui,'.cl').onclick=()=>{hist=[];empty();};
  q(ui,'.ex').onclick=async()=>{const st=q(ui,'.st');try{await navigator.clipboard.writeText(hist.join('\n'));st.textContent='Histórico copiado (no original, baixa .txt)';}catch(e){st.textContent='Cópia bloqueada pelo navegador';}T(setTimeout(()=>st.textContent='Online',2500));};
};

/* ================= COMPARADOR (Streamlit) ================= */
DEMOS.precos=d=>{
  const ui=el(`<div class="app" style="font-family:'Source Sans Pro','Segoe UI',sans-serif">${chrome('localhost:8501')}
   <div style="display:grid;grid-template-columns:190px 1fr" class="stg">
    <aside style="background:#f0f2f6;padding:14px;font-size:12.5px;color:#31333f">
      <b style="font-size:14px">ℹ️ Como usar</b><ol style="padding-left:16px;margin:6px 0 14px"><li>Digite o produto</li><li>Clique em Comparar</li><li>Aguarde a busca nos sites</li><li>Veja a análise</li></ol>
      <b style="font-size:14px">🔍 Sites pesquisados</b><ul style="padding-left:16px;margin:6px 0 14px"><li>Mercado Livre</li><li>Buscapé</li><li>Google Shopping</li><li>Zoom</li></ul>
      <b style="font-size:14px">⚠️ Aviso</b><p style="margin:6px 0 0">Alguns resultados podem ser simulados devido a proteções dos sites.</p>
    </aside>
    <div style="padding:18px 20px;color:#31333f;min-width:0">
      <h4 style="font-size:24px;margin:0 0 12px;font-weight:700">🛒 Comparador de Preços Inteligente</h4>
      <label style="font-size:13px">🔍 Digite o produto que deseja pesquisar:</label>
      <div style="display:flex;gap:8px;margin:4px 0 10px;flex-wrap:wrap"><input type="text" class="pin" value="Fone de ouvido bluetooth" style="flex:1;min-width:180px;background:#f0f2f6;border:1px solid #f0f2f6;color:#31333f;border-radius:8px;padding:8px 10px"><button class="go" style="background:#ff4b4b;color:#fff;border:0;border-radius:8px;padding:8px 14px;font-weight:600">🔍 Comparar Preços</button></div>
      <div class="quick" style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px"></div>
      <div class="out"></div>
      <details style="margin-top:14px;border:1px solid #e6e9ef;border-radius:8px;padding:8px 12px"><summary style="cursor:pointer;font-size:13px">🧪 Testar clean_price (mesma regex do app)</summary><input type="text" class="pr" value="Por apenas R$ 1.234,56 à vista" style="margin-top:8px;background:#f0f2f6;border:0;color:#31333f;border-radius:6px;padding:7px 10px;width:100%"><div class="pout" style="font-family:var(--mono);font-size:12.5px;margin-top:6px"></div></details>
    </div></div></div>`);
  d.appendChild(ui);
  if(window.innerWidth<700)q(ui,'.stg').style.gridTemplateColumns='1fr';
  const out=q(ui,'.out');
  [['📱 iPhone 13',3499],['💻 Notebook Dell',3799],['🖱️ Mouse Gamer',149],['📺 Smart TV 55',2599]].forEach(([l])=>{const b=el('<button style="background:#fff;border:1px solid #d6d6d9;border-radius:8px;padding:5px 10px;font-size:12.5px;color:#31333f">'+l+'</button>');b.onclick=()=>{q(ui,'.pin').value=l.replace(/^\S+\s/,'');go();};q(ui,'.quick').appendChild(b);});
  const BASE={'iphone 13':3499,'notebook dell':3799,'mouse gamer':149,'smart tv 55':2599};
  const SITES=['Mercado Livre','Amazon','Magazine Luiza','Casas Bahia'];
  const COLORS=['#ffe600','#ff9900','#0086ff','#0033a0'];
  let busy=false;
  async function go(){if(busy)return;busy=true;const prod=q(ui,'.pin').value.trim()||'produto';const key=norm(prod);
    out.innerHTML='<div style="font-size:13px" class="stt"></div><div style="height:6px;background:#f0f2f6;border-radius:3px;margin:6px 0 12px"><div class="pb" style="height:100%;width:0;background:#ff4b4b;border-radius:3px;transition:width .3s"></div></div>';
    const fns=['Mercado Livre','Buscapé','Google Shopping','Zoom'];
    for(let i=0;i<fns.length;i++){q(out,'.stt').textContent='Buscando no '+fns[i]+'...';q(out,'.pb').style.width=((i+1)/fns.length*100)+'%';await wait(420);}
    const base=BASE[key]||(80+hash(key)%2400);
    const res=SITES.map((s,i)=>({site:s,preco:+(base*(0.78+((hash(key+s)%38)/100))).toFixed(2),c:COLORS[i]}));
    const ps=res.map(r=>r.preco),mn=Math.min(...ps),mx=Math.max(...ps),avg=ps.reduce((a,b)=>a+b,0)/ps.length;const best=res.find(r=>r.preco===mn);
    const sv=mx-mn,svp=mx>0?sv/mx*100:0;
    let rec;if(svp>20)rec=['#d4edda','#155724','🟢 <b>VALE MUITO A PENA!</b> Você pode economizar '+svp.toFixed(1)+'% comprando no '+best.site];else if(svp>10)rec=['#fff3cd','#856404','🟡 <b>Vale a pena</b> comprar no '+best.site+' - economia de '+svp.toFixed(1)+'%'];else if(svp>5)rec=['#ffe5d0','#8a4b0f','🟠 <b>Pequena diferença</b> - '+best.site+' ainda é a melhor opção'];else rec=['#f8d7da','#721c24','🔴 <b>Preços similares</b> - qualquer opção é boa. Considere frete e prazo de entrega.'];
    const sorted=[...res].sort((a,b)=>a.preco-b.preco);
    out.innerHTML='<div style="background:#e8f3fd;color:#0d4f8b;border-radius:8px;padding:9px 12px;font-size:13px;margin-bottom:12px">ℹ️ Resultados simulados para demonstração (sites com proteção anti-bot)</div>'+
     '<b style="font-size:16px">📋 Resultados encontrados:</b><div style="margin:8px 0 14px">'+sorted.map(r=>'<div style="display:grid;grid-template-columns:1.1fr 2fr .9fr .8fr;gap:8px;padding:7px 0;border-bottom:1px solid #eee;font-size:13px;align-items:center"><b>'+r.site+'</b><span style="color:#555;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(prod)+' - Oferta '+r.site+'...</span><span style="font-weight:700;color:'+(r===best?'#09ab3b':'#31333f')+'">'+brl(r.preco)+'</span><span style="color:#ff4b4b">🔗 Ver oferta</span></div>').join('')+'</div>'+
     '<b style="font-size:16px">📊 Comparação Visual</b><div style="display:flex;align-items:flex-end;gap:14px;height:150px;padding:10px 6px 0;border-bottom:1px solid #ddd;margin:8px 0 4px">'+sorted.map(r=>'<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%"><span style="font-size:11px;margin-bottom:3px">'+brl(r.preco)+'</span><div class="vb" style="width:70%;height:0;background:'+r.c+';border-radius:3px 3px 0 0;transition:height .6s" data-h="'+(r.preco/mx*100)+'"></div></div>').join('')+'</div><div style="display:flex;gap:14px;padding:0 6px;font-size:11px;color:#666">'+sorted.map(r=>'<span style="flex:1;text-align:center">'+r.site+'</span>').join('')+'</div>'+
     '<b style="font-size:16px;display:block;margin-top:16px">🎯 Análise e Recomendação</b><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:8px 0">'+[['💰 Menor Preço',brl(mn)],['📊 Preço Médio',brl(avg)],['💸 Economia Máxima',brl(sv)]].map(m=>'<div><div style="font-size:12px;color:#666">'+m[0]+'</div><div style="font-size:20px;font-weight:600">'+m[1]+'</div></div>').join('')+'</div><div style="background:'+rec[0]+';color:'+rec[1]+';border-radius:8px;padding:10px 12px;font-size:13.5px">'+rec[2]+'</div>';
    requestAnimationFrame(()=>out.querySelectorAll('.vb').forEach(v=>v.style.height=v.dataset.h+'%'));busy=false;}
  q(ui,'.go').onclick=go;q(ui,'.pin').onkeydown=e=>{if(e.key==='Enter')go();};
  const clean=t=>{const pats=[/R\$\s*(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)/,/(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)/];for(const p of pats){const m=t.match(p);if(m)return parseFloat(m[1].replace(/\./g,'').replace(',','.'));}return null;};
  const cp=()=>{const v=clean(q(ui,'.pr').value);q(ui,'.pout').innerHTML='clean_price(...) → <b style="color:'+(v===null?'#d93025':'#09ab3b')+'">'+(v===null?'None':v)+'</b>';};
  q(ui,'.pr').oninput=cp;cp();go();
};

/* ================= QUERY AGENDADA ================= */
DEMOS.agenda=d=>{
  const ui=el(`<div class="d-col"><div class="split"><div class="app dark">${chrome('terminal — python')}<div class="term tm" style="height:300px"></div></div>
   <div class="d-col"><div class="d-panel"><div class="muted" style="font-size:12px">relógio simulado</div><div class="ck" style="font-family:var(--display);font-size:40px;font-variant-numeric:tabular-nums;line-height:1.1">08:00</div><div class="d-row" style="margin-top:8px"><button class="dbtn go">▶ Rodar script</button><label style="font-size:13px;display:flex;gap:6px;align-items:center;color:var(--muted)"><input type="checkbox" class="fail"> Simular falha no banco</label></div></div>
   <div class="d-panel" style="padding:10px"><div class="muted" style="font-size:12px;margin-bottom:6px">Caixa de entrada do destinatário</div><div class="inbox d-col" style="gap:8px;max-height:230px;overflow-y:auto"><span class="muted" style="font-size:13px">Nenhum e-mail ainda.</span></div></div></div></div>
   <p class="hint">Agendamento igual ao código: schedule.every().day.at("11:00") e .at("16:30"). Banco, query e destinatários são fictícios; senhas ficam fora do repositório.</p></div>`);
  d.appendChild(ui);const tm=q(ui,'.tm'),log=termLog(tm);
  log('<span class="m">$ python Exporta_Query_Envia_Email_Python.py</span>');
  let tick=null;
  q(ui,'.go').onclick=()=>{clearInterval(tick);tm.innerHTML='';q(ui,'.inbox').innerHTML='<span class="muted" style="font-size:13px">Nenhum e-mail ainda.</span>';let first=true;
    log('<span class="m">$ python Exporta_Query_Envia_Email_Python.py</span>');log('🕒 Script agendado para rodar diariamente às 11:00 e 16:30.');
    let m=8*60,busy=false;
    tick=T(setInterval(async()=>{if(busy)return;m+=5;if(m>18*60){clearInterval(tick);log('<span class="m"># while True: schedule.run_pending(); time.sleep(30)  → segue rodando amanhã</span>');return;}
      const hh=pad(Math.floor(m/60))+':'+pad(m%60);q(ui,'.ck').textContent=hh;
      if(hh==='11:00'||hh==='16:30'){busy=true;const t=today();const now=t.d+' '+hh;const fn='relatorio_'+t.ymd+'_'+hh.replace(':','')+'.xlsx';
        log('<span class="m"># psycopg2.connect(host=***, port=5439) → Redshift</span>');await wait(450);
        if(q(ui,'.fail').checked){log('<span class="r">❌ Erro durante a execução:</span>');log('<span class="r">connection to server at "***", port 5439 failed: timeout expired</span>');busy=false;return;}
        const n=900+Math.floor(Math.random()*700);
        log('<span class="m"># pd.read_sql_query(SQL_QUERY) → '+n.toLocaleString('pt-BR')+' linhas</span>');await wait(400);
        log('<span class="m"># df.to_excel("'+fn+'")</span>');await wait(350);
        log('<span class="m"># yag.send(to=EMAIL_TO, attachments="'+fn+'")</span>');await wait(350);
        log('<span class="p">✅ Relatório enviado com sucesso às '+now+'!</span>');
        const ib=q(ui,'.inbox');if(first){ib.innerHTML='';first=false;}
        ib.prepend(el('<div class="gmail" style="animation:rowin .3s both"><div class="gh"><b>Base Sem Acesso - '+now+'</b><span>relatorios@empresa-exemplo.com → time-cs@empresa-exemplo.com</span></div><div class="gb">Segue a base atualizada.<br><span class="att"><i></i>'+fn+'</span></div></div>'));
        busy=false;}
    },reduce?5:70));};
};

/* ================= RESUMO EXCEL IA ================= */
DEMOS.resumo=d=>{
  const OBS=['Cliente pediu integração com o ERP','Reclamou da demora no retorno do suporte','','Elogiou a facilidade do painel','Solicitou treinamento para a equipe nova','Teve problema com importação de planilha','Quer relatório por vendedor','','Pediu desconto na renovação','Relatou lentidão no horário de pico','Gostou do atendimento por chat','Dúvida sobre permissões de usuário','Reclamou da demora para resolver chamado','   ','Pediu integração com a loja virtual','Elogiou o suporte pelo WhatsApp','Erro ao importar contatos em CSV','Quer treinamento sobre automações','Relatou lentidão ao abrir relatórios','Pediu desconto por pagar anual','Elogiou a rapidez da implantação','','Quer relatório de produtividade do time','Integração com o CRM parou de sincronizar'];
  const ui=el(`<div class="d-col"><div class="split"><div class="app"><div class="sh-title"><span class="ico" style="background:#185c37"></span><b>observacoes_clientes.xlsx</b></div><div class="sh-grid xg" style="max-height:300px"></div><div class="sh-tabs"><button aria-selected="true">Planilha1</button></div></div>
   <div class="app dark">${chrome('terminal — python')}<div class="term tm" style="height:270px"></div></div></div>
   <div class="d-panel d-row"><label class="f" style="flex:1;min-width:220px" for="rsz">textwrap.wrap(width=<span class="v" id="rszv"></span>) <small class="muted">no projeto: 15.000 caracteres (~3.750 tokens)</small><input type="range" id="rsz" min="120" max="900" step="20" value="240"></label><button class="dbtn go">▶ python Leitura_Excel_IA.py</button></div>
   <p class="hint">Observações fictícias. Os resumos aqui são montados por contagem de temas; no original, cada bloco vai ao llama3-70b com temperature 0.3.</p></div>`);
  d.appendChild(ui);
  const g=q(ui,'.xg');
  const drawX=clean=>{g.innerHTML='<table><thead><tr><th></th><th>A</th></tr></thead><tbody><tr class="h"><td class="rn">1</td><td>Observação</td></tr>'+OBS.map((o,i)=>{const blank=!o.trim();return '<tr><td class="rn">'+(i+2)+'</td><td style="'+(clean&&blank?'background:#fce8e6;color:#d93025;font-style:italic':'')+'">'+(blank&&clean?'vazia · removida':esc(o))+'</td></tr>';}).join('')+'</tbody></table>';};
  drawX(false);
  const tm=q(ui,'.tm'),log=termLog(tm);log('<span class="m">$ python Leitura_Excel_IA.py</span>');
  const wrap=(txt,w)=>{const words=txt.split(/\s+/);const out=[];let cur='';words.forEach(x=>{if((cur+' '+x).trim().length>w&&cur){out.push(cur);cur=x;}else cur=(cur+' '+x).trim();});if(cur)out.push(cur);return out;};
  const THEMES=[['integração com sistemas',/integra/],['demora e lentidão',/demora|lentid/],['erros de importação',/import|erro/],['pedidos de relatório',/relat/],['treinamento',/treinamento/],['negociação de preço',/desconto/],['elogios ao atendimento e à facilidade',/elogi|gostou/],['permissões',/permiss/]];
  const themes=t=>THEMES.map(([n,r])=>[n,(t.match(new RegExp(r.source,'gi'))||[]).length]).filter(x=>x[1]).sort((a,b)=>b[1]-a[1]);
  q(ui,'#rsz').oninput=()=>q(ui,'#rszv').textContent=q(ui,'#rsz').value;q(ui,'#rszv').textContent=q(ui,'#rsz').value;
  let busy=false;
  q(ui,'.go').onclick=async()=>{if(busy)return;busy=true;tm.innerHTML='';log('<span class="m">$ python Leitura_Excel_IA.py</span>');
    drawX(true);const obs=OBS.map(s=>s.trim()).filter(Boolean);
    log('<span class="m"># '+OBS.length+' linhas lidas · '+(OBS.length-obs.length)+' vazias removidas</span>');
    const partes=wrap(obs.join('\n'),+q(ui,'#rsz').value);
    for(let i=0;i<partes.length;i++){log('▶️ Resumindo parte '+(i+1)+'/'+partes.length+'...');await wait(380);const th=themes(partes[i]).slice(0,2).map(x=>x[0]);log('<span class="m">   ↳ '+esc(th.join(' e ')||'observações diversas')+'</span>');}
    await wait(500);const all=themes(obs.join(' '));
    log('');log('<span class="p">✅ RESUMO FINAL DAS OBSERVAÇÕES:</span>');
    log(esc('Os clientes trazem principalmente '+all.slice(0,3).map(x=>x[0]+' ('+x[1]+')').join(', ')+'. Também aparecem '+all.slice(3,6).map(x=>x[0]).join(', ')+'. Recomenda-se priorizar os pontos de atrito técnicos e manter o que foi elogiado.'));
    busy=false;};
};

/* ================= DISPARO DE E-MAIL ================= */
DEMOS.email=d=>{
  const rows=[['Nome do cliente','E-mail do cliente','Nome do Atendente','Data do Contato','Status do envio'],['Ana Ribeiro','ana@exemplo.com','Carla','10/11/2026',''],['Bruno Matos','bruno@exemplo.com','Diego','11/11/2026','Enviado'],['Clara Nunes','clara@exemplo.com','Carla','12/11/2026',''],['Davi Prado','davi@exemplo.com','Elisa','13/11/2026','']];
  const box=el('<div class="d-col"></div>');d.appendChild(box);
  const prev=el('<div></div>');
  const sh=makeSheet(box,{file:'Atendimentos · pesquisa de satisfação',menu:'✉️ Disparo E-mail',items:[['Enviar email para o cliente',()=>flow()]]});
  box.appendChild(el('<p class="hint">Abra o menu ✉️ Disparo E-mail e digite um e-mail da coluna B. Tente também um e-mail que não existe ou o de quem já recebeu. Nada é enviado de verdade.</p>'));
  box.appendChild(prev);
  const draw=()=>sh.render(rows,{minRows:8,cls:(r,c,v)=>c===4&&r>0?(v==='Enviado'?'pos':v?'neg':''):''});draw();
  async function flow(){
    const v=await sh.prompt('Enviar email','Digite o e-mail do cliente:');if(v===null)return;
    const em=v.trim();if(!em){await sh.alert('Você deve digitar um e-mail válido.');return;}
    const i=rows.findIndex((r,k)=>k>0&&r[1].toLowerCase()===em.toLowerCase());
    if(i<0){await sh.alert('Cliente com o e-mail "'+em+'" não encontrado na planilha.');return;}
    const r=rows[i];if(r[4]==='Enviado'){await sh.alert('E-mail já foi enviado para esse cliente.');return;}
    r[4]='Enviado';draw();const td=sh.cell(i,4);if(td)td.classList.add('new');
    prev.innerHTML='<div class="gmail" style="animation:rowin .3s both"><div class="gh"><b>Como foi seu atendimento com o(a) '+esc(r[2])+'?</b><span>para '+esc(r[1])+' · enviado via GmailApp.sendEmail()</span></div><div class="gb" style="background:#fafafa"><div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;border:1px solid #eee;padding:20px;background:#fff"><div style="display:inline-block;border:1px dashed #bbb;color:#888;font-size:11px;padding:10px 18px;margin-bottom:16px">Sua Logo Aqui</div><h2 style="color:#2c3e50;font-family:Arial,sans-serif;font-size:20px;margin:0 0 10px">Olá, '+esc(r[0])+'!</h2><p>Esperamos que seu atendimento com <strong>'+esc(r[2])+'</strong> tenha sido ótimo 😊</p><p>Para continuarmos melhorando, gostaríamos que você respondesse uma pesquisa rápida.</p><p><span style="background-color:#0a7fcb;color:white;padding:12px 20px;border-radius:5px;display:inline-block">👉 Responder pesquisa</span></p><p>Obrigado pela confiança!</p><p><em>Equipe de Atendimento</em></p></div></div></div>';
    await sh.alert('E-mail enviado com sucesso para '+r[0]+' ('+r[1]+').');
  }
};

/* ================= TÁVINDO.AI ================= */
DEMOS.tavindo=d=>{
  const ui=el(`<div class="split" style="grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr)">
   <div class="d-col"><div class="waphone"><div class="wahead"><div class="av">TV</div><div><b>TáVindo.AI</b><small>Online agora</small></div></div><div class="wabody"></div><form class="wafoot"><input type="text" placeholder="Mensagem" aria-label="Mensagem" style="flex:1"><button aria-label="Enviar">➤</button></form></div><div class="qr ex" style="justify-content:center"></div></div>
   <div class="d-col"><div class="n8n" style="padding:14px 10px 10px"><div class="bar8" style="margin-bottom:8px"><b>Fluxo no n8n</b><span class="muted mono" style="font-size:11px" class="fst">aguardando mensagem</span></div><div class="nflow tvf"></div></div>
   <div class="d-panel d-col" style="gap:10px"><b style="font-size:14px">Modelo de chegada</b><span class="muted" style="font-size:12.5px">A SPTrans dava velocidade média e posição, mas ônibus não é helicóptero: o trajeto real tem curvas e semáforos.</span>
    <label class="f" for="tdist">Distância até o ponto (Google Maps): <span class="v" id="tdv"></span> km<input type="range" id="tdist" min="0.3" max="6" step="0.1" value="1.6"></label>
    <label class="f" for="tvel">Velocidade média (SPTrans): <span class="v" id="tvv"></span> km/h<input type="range" id="tvel" min="8" max="40" step="1" value="18"></label>
    <label class="f" for="tfat">Fator de trajeto real: <span class="v" id="tfv"></span>x<input type="range" id="tfat" min="1" max="1.8" step="0.05" value="1.35"></label>
    <label class="f" for="tsem">Semáforos no caminho: <span class="v" id="tsv"></span><input type="range" id="tsem" min="0" max="15" step="1" value="5"></label>
    <div class="bign" style="grid-template-columns:1fr 1fr"><div><b class="neu" id="tnaive"></b><span>linha reta (ingênuo)</span></div><div><b class="pos" id="tcorr"></b><span>modelo corrigido</span></div></div>
    <span class="hint">Parâmetros ilustrativos. O original era calibrado todo dia com os deslocamentos do próprio Gabriel.</span></div></div></div>`);
  d.appendChild(ui);
  const NODES=[['💬','WhatsApp','Evolution API'],['🧠','Intenção','LLM'],['🚌','SPTrans','posição'],['📍','Google Maps','distância'],['🧮','Modelo ETA',''],['📤','Resposta','']];
  const fl=q(ui,'.tvf');fl.innerHTML=NODES.map((n,i)=>(i?'<div class="nwire" style="width:14px"></div>':'')+'<div class="nn" style="width:62px"><div class="sq" style="width:46px;height:46px;font-size:18px">'+n[0]+'<span class="ck">✓</span></div><span style="font-size:10.5px">'+n[1]+'</span></div>').join('');
  const nodes=[...fl.querySelectorAll('.nn')],wires=[...fl.querySelectorAll('.nwire')];
  const eta=()=>{const D=+q(ui,'#tdist').value,V=+q(ui,'#tvel').value,F=+q(ui,'#tfat').value,S=+q(ui,'#tsem').value;
    q(ui,'#tdv').textContent=D.toFixed(1);q(ui,'#tvv').textContent=V;q(ui,'#tfv').textContent=F.toFixed(2);q(ui,'#tsv').textContent=S;
    const naive=D/V*60,corr=D*F/V*60+S*0.4;q(ui,'#tnaive').textContent=Math.max(1,Math.round(naive))+' min';q(ui,'#tcorr').textContent=Math.max(1,Math.round(corr))+' min';return Math.max(1,Math.round(corr));};
  ['#tdist','#tvel','#tfat','#tsem'].forEach(s=>q(ui,s).oninput=eta);eta();
  const body=q(ui,'.wabody');const tm=()=>{const n=new Date();return pad(n.getHours())+':'+pad(n.getMinutes());};
  const add=(t,me)=>{body.appendChild(el('<div class="wamsg '+(me?'me':'bot')+'">'+t+'<small>'+tm()+(me?' ✓✓':'')+'</small></div>'));body.scrollTop=1e9;};
  add('👋 Olá! Digite uma linha de ônibus, metrô ou CPTM com o endereço para consultar horários em tempo real.');
  const MET={1:'1-Azul',2:'2-Verde',3:'3-Vermelha',4:'4-Amarela',5:'5-Lilás',7:'7-Rubi',8:'8-Diamante',9:'9-Esmeralda',10:'10-Turquesa',11:'11-Coral',12:'12-Safira',13:'13-Jade',15:'15-Prata'};
  const demoNote='\n\n<em>*Esta é apenas uma demonstração</em>';
  async function animate(path){nodes.forEach(n=>{n.classList.remove('on','done');n.style.opacity='';});wires.forEach(w=>w.classList.remove('on'));
    for(let i=0;i<nodes.length;i++){if(!path.includes(i)){nodes[i].style.opacity='.3';continue;}nodes[i].classList.add('on');if(wires[i-1])wires[i-1].classList.add('on');await wait(260);nodes[i].classList.replace('on','done');}}
  let busy=false;
  async function send(v){if(busy||!v.trim())return;busy=true;add(esc(v),true);
    const bus=v.match(/\b(\d{3,4}[A-Za-z]?-\d{2})\b\s*(.*)/);const met=v.match(/linha\s*(\d{1,2})/i);
    if(bus){await animate([0,1,2,3,4,5]);const place=bus[2].trim()||'seu ponto';q(ui,'#tdist').value=(0.6+(hash(norm(place))%40)/10).toFixed(1);const m=eta();
      add('O '+esc(bus[1].toUpperCase())+' passará em '+m+' minuto'+(m>1?'s':'')+' '+(/^(rua|avenida|av\.|alameda|estrada|praça)/i.test(place)?'na ':'no ')+esc(place)+demoNote);}
    else if(met&&MET[met[1]]){await animate([0,1,5]);add('Linha '+MET[met[1]]+' operando normalmente'+demoNote);}
    else{await animate([0,1,5]);add('Não entendi 🤔 Envie a linha e o endereço, por exemplo: 875A-10 Rua Augusta');}
    busy=false;}
  ['106-10 Avenida Paulista','875A-10 Rua Augusta','477P-10 Terminal Bandeira','Linha 1-Azul','Linha 4-Amarela','CPTM Linha 7'].forEach(s=>{const b=el('<button>'+s+'</button>');b.onclick=()=>send(s);q(ui,'.ex').appendChild(b);});
  q(ui,'.wafoot').onsubmit=e=>{e.preventDefault();const i=q(ui,'.wafoot input');send(i.value);i.value='';};
};

/* ================= CADASTRO SEM DUPLICIDADE ================= */
DEMOS.dedup=d=>{
  const base=[['Maria Souza','maria.souza@alfa.com','(11) 98877-1122'],['João Pereira','joao@beta.io','(11) 97766-5544'],['Ana Lúcia Reis','ana.reis@gama.com.br','(21) 99123-4567'],['Pedro Alves','pedro@delta.com','(31) 98888-0000'],['Carla Mendes','carla@epsilon.com','(41) 99654-3210']];
  const ex=[['Maria Souza','maria.souza@alfa.com','11 90000-0000','E-mail já existe'],['Joana Pereira','joana@nova.com','(11) 97766-5544','Telefone já existe'],['Ana Lucia Reiss','analucia@outra.com','(21) 98000-1111','Nome parecido'],['Rafael Torres','rafael@zeta.com','(51) 99777-2020','Lead novo']];
  const ui=el(`<div class="app dark">${chrome('app-interno / leads / novo')}<div style="padding:14px" class="d-col">
   <div class="d-panel d-col"><div class="d-row" style="justify-content:space-between"><b style="font-size:15px">Novo lead</b><div class="qr dex"></div></div>
    <div class="d-row"><input type="text" id="nn" placeholder="Nome" style="flex:1;min-width:140px" aria-label="Nome"><input type="text" id="ne" placeholder="E-mail" style="flex:1;min-width:160px" aria-label="E-mail"><input type="text" id="np" placeholder="Telefone" style="flex:1;min-width:120px" aria-label="Telefone"><button class="dbtn" id="ncheck">Cadastrar no CRM</button></div><div id="nres" style="min-height:22px;font-size:14px"></div></div>
   <div class="split" style="grid-template-columns:1fr 1fr"><div class="d-panel"><div class="muted" style="font-size:12px;margin-bottom:6px">Contatos no CRM (<span id="dcount"></span>)</div><div class="scroll"><table class="grid" id="dtab"></table></div></div><div class="d-panel"><div class="muted" style="font-size:12px;margin-bottom:6px">Fila de aprovação · RevOps</div><div id="dq" class="d-col" style="gap:8px"></div></div></div></div></div>`);
  d.appendChild(ui);d.appendChild(el('<p class="hint" style="margin-top:10px">Contatos fictícios. Regras da demo: e-mail ou telefone igual (8 últimos dígitos) barram o cadastro; nome com 80%+ de semelhança vira card para RevOps.</p>'));
  ex.forEach((e,i)=>{const b=el('<button>'+e[3]+'</button>');b.onclick=()=>{q(ui,'#nn').value=e[0];q(ui,'#ne').value=e[1];q(ui,'#np').value=e[2];q(ui,'#nres').innerHTML='';};q(ui,'.dex').appendChild(b);});
  const nE=e=>e.trim().toLowerCase(),nP=p=>p.replace(/\D/g,'').slice(-8),nN=n=>norm(n).replace(/\s+/g,' ').trim();
  const lev=(a,b)=>{const m=[...Array(b.length+1).keys()];for(let i=1;i<=a.length;i++){let p=m[0];m[0]=i;for(let j=1;j<=b.length;j++){const t=m[j];m[j]=Math.min(m[j]+1,m[j-1]+1,p+(a[i-1]===b[j-1]?0:1));p=t;}}return m[b.length];};
  const sim=(a,b)=>1-lev(a,b)/Math.max(a.length,b.length,1);
  const queue=[];
  const draw=hl=>{q(ui,'#dcount').textContent=base.length;q(ui,'#dtab').innerHTML='<tbody>'+base.map((l,i)=>'<tr'+(i===hl?' style="background:color-mix(in srgb,var(--ok) 14%,transparent)"':'')+'><td style="padding:7px 4px">'+esc(l[0])+'<div class="mono muted" style="font-size:11px">'+esc(l[1])+' · '+esc(l[2])+'</div></td></tr>').join('')+'</tbody>';
    const dq=q(ui,'#dq');dq.innerHTML=queue.length?'':'<span class="muted" style="font-size:13px">Nenhum lead aguardando.</span>';
    queue.forEach((it,k)=>{const c=el('<div class="d-panel" style="border-left:3px solid var(--warn);padding:10px;background:var(--panel2)"><b>'+esc(it.lead[0])+'</b><div class="mono muted" style="font-size:11.5px">'+esc(it.lead[1])+'<br>parecido com '+esc(it.match)+' ('+it.pct+'%)</div><div class="d-row" style="margin-top:8px"><button class="dbtn" style="padding:4px 10px;font-size:12px">Aprovar</button><button class="dbtn ghost" style="padding:4px 10px;font-size:12px">Recusar</button></div></div>');
      const [ap,rc]=c.querySelectorAll('button');ap.onclick=()=>{queue.splice(k,1);base.push(it.lead);q(ui,'#nres').innerHTML='<span class="pill pos">Aprovado por RevOps</span> '+esc(it.lead[0])+' criado no CRM.';draw(base.length-1);};rc.onclick=()=>{queue.splice(k,1);q(ui,'#nres').innerHTML='<span class="pill neg">Recusado por RevOps</span> o vendedor é avisado para usar o contato existente.';draw();};dq.appendChild(c);});};
  draw();
  q(ui,'#ncheck').onclick=()=>{const n=[q(ui,'#nn').value.trim(),q(ui,'#ne').value.trim(),q(ui,'#np').value.trim()];const r=q(ui,'#nres');if(!n[0]){r.innerHTML='<span class="neg">Preencha pelo menos o nome.</span>';return;}
    const byE=n[1]&&base.find(l=>nE(l[1])===nE(n[1]));const byP=nP(n[2]).length===8&&base.find(l=>nP(l[2])===nP(n[2]));
    if(byE||byP){r.innerHTML='<span class="pill neg">Cadastro barrado</span> '+(byE?'e-mail':'telefone')+' já pertence a '+esc((byE||byP)[0])+'.';return;}
    let best=null,bs=0;base.forEach(l=>{const s=sim(nN(l[0]),nN(n[0]));if(s>bs){bs=s;best=l;}});
    if(bs>=0.8){queue.push({lead:n,match:best[0],pct:Math.round(bs*100)});r.innerHTML='<span class="pill wrn">Enviado para aprovação</span> nome '+Math.round(bs*100)+'% parecido com '+esc(best[0])+'.';draw();return;}
    base.push(n);r.innerHTML='<span class="pill pos">Lead criado</span> nenhum conflito encontrado.';draw(base.length-1);};
};

/* ================= PORTAL DE DASHBOARDS ================= */
DEMOS.hub=d=>{
  const DASH=[
   {n:'Receita & MRR',a:'Diretoria',k:[['MRR','R$ 1,24 mi'],['Crescimento','+3,1%'],['Ticket médio','R$ 412']],s:[42,45,44,48,52,55,58,61]},
   {n:'Funil comercial',a:'Vendas',k:[['Negócios abertos','163'],['Conversão','21%'],['Ciclo médio','18 dias']],s:[120,132,128,140,151,149,163,170]},
   {n:'Metas por vendedor',a:'Vendas',k:[['Meta do mês','83%'],['Acima da meta','4 de 9'],['Dias úteis','6']],s:[61,64,70,68,72,79,83,86]},
   {n:'Score de reuniões',a:'Vendas',k:[['Score médio','67'],['Contas quentes','12'],['Em risco','5']],s:[58,61,60,64,63,67,70,67]},
   {n:'Carteira & churn',a:'CS',k:[['Churn mensal','2,2%'],['Contas em risco','18'],['NRR','104%']],s:[3.1,2.9,3.0,2.6,2.4,2.5,2.2,2.2]},
   {n:'NPS e satisfação',a:'CS',k:[['NPS','60'],['Respostas','412'],['Detratores','9%']],s:[48,51,50,55,57,56,60,60]},
   {n:'Campanhas & leads',a:'Marketing',k:[['Leads no mês','410'],['CPL','R$ 38'],['MQL → SQL','27%']],s:[310,290,340,360,355,380,410,430]}];
  const USERS={'Diretora (admin)':[0,1,2,3,4,5,6],'Gestor de Vendas':[1,2,3],'Vendedor':[1,3],'Analista de CS':[4,5],'Marketing':[6,1]};
  const perm=JSON.parse(JSON.stringify(USERS));let user='Diretora (admin)',sel=0,view='dash';
  const ui=el(`<div class="app dark">${chrome('portal-dashboards.app-interno')}<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid var(--line);flex-wrap:wrap"><b style="font-family:var(--display);font-size:16px">▦ Portal de Dashboards</b><label style="display:flex;gap:8px;align-items:center;font-size:13px;color:var(--muted)">Entrar como<select class="us" style="width:auto">${Object.keys(USERS).map(u=>'<option>'+u+'</option>').join('')}</select></label></div>
   <div class="pg" style="display:grid;grid-template-columns:210px 1fr;min-height:340px"><div class="sb" style="border-right:1px solid var(--line);padding:10px;display:flex;flex-direction:column;gap:3px"></div><div class="mn" style="padding:16px;min-width:0"></div></div></div>`);
  d.appendChild(ui);d.appendChild(el('<p class="hint" style="margin-top:10px">Perfis, dashboards e números fictícios. Entre como Diretora para editar as permissões e depois troque de usuário.</p>'));
  if(window.innerWidth<700)q(ui,'.pg').style.gridTemplateColumns='1fr';
  const spark=v=>{const mn=Math.min(...v),mx=Math.max(...v);const W=520,H=150;const pts=v.map((y,i)=>[i*(W/(v.length-1)),H-12-((y-mn)/(mx-mn||1))*(H-30)]);const p=pts.map(x=>x.map(n=>n.toFixed(1)).join(',')).join(' ');const l=pts[pts.length-1];
    return '<svg viewBox="0 0 '+W+' '+H+'" style="width:100%;height:auto;display:block" aria-hidden="true">'+[0.25,0.5,0.75].map(f=>'<line x1="0" x2="'+W+'" y1="'+H*f+'" y2="'+H*f+'" stroke="var(--line)" stroke-width="1"/>').join('')+'<polygon points="0,'+H+' '+p+' '+W+','+H+'" fill="color-mix(in srgb,var(--data) 18%,transparent)"/><polyline points="'+p+'" fill="none" stroke="var(--data)" stroke-width="2.5"/><circle cx="'+l[0].toFixed(1)+'" cy="'+l[1].toFixed(1)+'" r="5" fill="var(--accent)"/></svg>';};
  const draw=()=>{const ids=perm[user];if(!ids.includes(sel))sel=ids[0];const admin=user.includes('admin');if(view==='perm'&&!admin)view='dash';
    const sb=q(ui,'.sb');sb.innerHTML='<span class="muted mono" style="font-size:10.5px;padding:4px 8px">MEUS DASHBOARDS</span>'+ids.map(i=>'<button data-i="'+i+'" style="text-align:left;border:0;border-radius:7px;padding:7px 9px;font-size:13px;background:'+(view==='dash'&&i===sel?'var(--panel2)':'none')+';color:'+(view==='dash'&&i===sel?'var(--text)':'var(--muted)')+'">'+DASH[i].n+'</button>').join('')+
      '<span class="muted" style="font-size:12px;padding:8px 9px">🔒 '+(DASH.length-ids.length)+' sem acesso</span>'+(admin?'<button data-p="1" style="text-align:left;border:0;border-radius:7px;padding:7px 9px;font-size:13px;margin-top:auto;background:'+(view==='perm'?'var(--panel2)':'none')+';color:var(--accent)">⚙ Permissões</button>':'');
    sb.querySelectorAll('[data-i]').forEach(b=>b.onclick=()=>{sel=+b.dataset.i;view='dash';draw();});const pb=sb.querySelector('[data-p]');if(pb)pb.onclick=()=>{view='perm';draw();};
    const mn=q(ui,'.mn');
    if(!ids.length){mn.innerHTML='<p class="muted">Este usuário ainda não tem dashboards liberados.</p>';return;}
    if(view==='perm'){const us=Object.keys(USERS);mn.innerHTML='<b style="font-size:16px">Permissões por usuário</b><p class="hint" style="margin:4px 0 10px">Marque o que cada pessoa pode ver.</p><div class="scroll"><table class="grid"><thead><tr><th>dashboard</th>'+us.map(x=>'<th>'+x.split(' ')[0]+'</th>').join('')+'</tr></thead><tbody>'+DASH.map((x,i)=>'<tr><td>'+x.n+'</td>'+us.map(u=>'<td><input type="checkbox" data-u="'+u+'" data-i="'+i+'" aria-label="'+u+' vê '+x.n+'"'+(perm[u].includes(i)?' checked':'')+(u.includes('admin')?' disabled':'')+'></td>').join('')+'</tr>').join('')+'</tbody></table></div>';
      mn.querySelectorAll('input[data-u]').forEach(c=>c.onchange=()=>{const a=perm[c.dataset.u],i=+c.dataset.i;if(c.checked){if(!a.includes(i))a.push(i);a.sort((x,y)=>x-y);}else a.splice(a.indexOf(i),1);});return;}
    const D=DASH[sel];mn.innerHTML='<div class="d-row" style="justify-content:space-between"><div><span class="muted mono" style="font-size:11px">'+D.a.toUpperCase()+'</span><h4 style="margin:2px 0 0;font-family:var(--display);font-size:22px">'+D.n+'</h4></div><span class="pill pos">atualizado há 5 min</span></div><div class="bign" style="grid-template-columns:repeat(3,1fr);margin:12px 0">'+D.k.map(k=>'<div><b>'+k[1]+'</b><span>'+k[0]+'</span></div>').join('')+'</div><div class="d-panel" style="padding:10px">'+spark(D.s)+'<div class="d-row muted mono" style="justify-content:space-between;font-size:10.5px;margin-top:4px"><span>abr</span><span>mai</span><span>jun</span><span>jul</span><span>ago</span><span>set</span><span>out</span><span>nov</span></div></div>';};
  q(ui,'.us').onchange=e=>{user=e.target.value;view='dash';draw();};draw();
};

/* ================= n8n helpers ================= */
function n8nCanvas(host,title,steps,opts={}){
  const c=el('<div class="n8n"><div class="bar8"><b>'+esc(title)+'</b><button class="exec">▶ Test workflow</button></div><div class="nflow"></div><div class="nout">Clique em “Test workflow”.</div></div>');host.appendChild(c);
  const fl=q(c,'.nflow');
  const draw=st=>{fl.innerHTML=st.map((s,i)=>(i?'<div class="nwire"></div>':'')+'<div class="nn"><div class="sq">'+s[0]+'<span class="ck">✓</span></div><span>'+esc(s[1])+'</span><span class="items"></span></div>').join('');};
  draw(steps);
  return {el:c,btn:q(c,'.exec'),out:q(c,'.nout'),redraw:draw,
    async run(items,outputs){const nodes=[...fl.querySelectorAll('.nn')],wires=[...fl.querySelectorAll('.nwire')];nodes.forEach(n=>{n.classList.remove('on','done');q(n,'.items').textContent='';});wires.forEach(w=>w.classList.remove('on'));
      for(let i=0;i<nodes.length;i++){nodes[i].classList.add('on');if(wires[i-1])wires[i-1].classList.add('on');q(c,'.nout').textContent=outputs[i];await wait(560);nodes[i].classList.replace('on','done');q(nodes[i],'.items').textContent=items[i];}}};
}

/* ================= RADAR ================= */
DEMOS.radar=d=>{
  const SIG=[['venda','venda / aquisição'],['ipo','abertura de capital'],['captacao','captação'],['expansao','expansão'],['contratacao','contratação em massa']];
  const NEWS=[['Empresa Alfa anuncia aquisição de concorrente regional','venda','Varejo'],['Fintech Beta protocola pedido de IPO','ipo','Serviços financeiros'],['Startup Gama capta R$ 40 milhões em série B','captacao','Tecnologia'],['Rede Delta abre 12 novas lojas no Nordeste','expansao','Varejo'],['Indústria Épsilon contrata 300 pessoas','contratacao','Indústria'],['Grupo Zeta é vendido para fundo de investimento','venda','Serviços financeiros'],['Clínica Eta inaugura terceira unidade','expansao','Saúde'],['Time de futebol local vence campeonato','—','—'],['Varejista Teta anuncia plano de abrir capital em 2027','ipo','Varejo']];
  const SEG=['Varejo','Serviços financeiros','Tecnologia','Indústria','Saúde'];
  const box=el('<div class="d-col"><div class="d-panel d-col" style="gap:8px"><b style="font-size:14px">Configuração do ICP</b><div class="chips rseg">'+SEG.map((s,i)=>'<button class="chip" aria-pressed="'+(i<3)+'" data-s="'+s+'">'+s+'</button>').join('')+'</div><b style="font-size:14px">Sinais de compra</b><div class="chips rsig">'+SIG.map(s=>'<button class="chip" aria-pressed="true" data-g="'+s[0]+'">'+s[1]+'</button>').join('')+'</div></div></div>');
  d.appendChild(box);
  box.querySelectorAll('.chip').forEach(b=>b.onclick=()=>b.setAttribute('aria-pressed',b.getAttribute('aria-pressed')!=='true'));
  const cv=n8nCanvas(box,'Radar de prospecção',[['⏰','Schedule · 08:00'],['📰','Buscar notícias'],['🎯','Filtro ICP'],['🧠','IA classifica sinal'],['💬','Canal comercial']]);
  const res=el('<div class="d-col" style="gap:6px"></div>');box.appendChild(res);
  box.appendChild(el('<p class="hint">Notícias, empresas e ICP fictícios. Palavras-chave, fontes e ICP reais omitidos.</p>'));
  let busy=false;
  cv.btn.onclick=async()=>{if(busy)return;busy=true;res.innerHTML='';
    const segs=[...box.querySelectorAll('.rseg [aria-pressed="true"]')].map(b=>b.dataset.s),sigs=[...box.querySelectorAll('.rsig [aria-pressed="true"]')].map(b=>b.dataset.g);
    const icp=NEWS.filter(n=>segs.includes(n[2]));const hits=icp.filter(n=>sigs.includes(n[1]));
    await cv.run(['1 item',NEWS.length+' items',icp.length+' items',hits.length+' items',hits.length+' msgs'],
      ['{ "trigger": "08:00", "timezone": "America/Sao_Paulo" }',JSON.stringify(NEWS.slice(0,2).map(n=>({titulo:n[0]})),null,1),JSON.stringify({segmentos:segs,mantidas:icp.length,descartadas:NEWS.length-icp.length},null,1),JSON.stringify(hits.slice(0,2).map(n=>({titulo:n[0],sinal:n[1],relevante:true})),null,1),'{ "enviadas": '+hits.length+', "canal": "#comercial" }']);
    res.innerHTML=hits.length?hits.map((n,k)=>'<div class="alert" style="animation-delay:'+k*90+'ms"><i style="background:#ff6d5a"></i><div><b>'+esc(n[0])+'</b><small>'+esc(n[2])+' · sinal: '+esc(SIG.find(s=>s[0]===n[1])[1])+' · enviado ao canal do time</small></div><span class="pill pos" style="margin-right:8px">abordar</span></div>').join(''):'<div class="d-panel muted">Nenhuma notícia combina com o ICP e os sinais selecionados.</div>';
    busy=false;};
  cv.btn.click();
};

/* ================= n8n FUNIL ================= */
DEMOS.n8n=d=>{
  const FLOWS={
   funil:{n:'Atualização de funil',steps:[['🪝','Webhook do CRM'],['🔀','IF · etapa'],['✏️','Set propriedades'],['📈','Mover etapa'],['✅','Criar tarefa']],items:['1 item','true','4 campos','1 item','1 tarefa'],out:['{ "evento": "reuniao_concluida", "negocio_id": 4821 }','{ "etapa_atual": "Qualificação", "regra_avanco": true }','{ "segmento": "Varejo", "origem": "Inbound", "porte": "Médio", "proximo_passo": "Proposta" }','{ "negocio_id": 4821, "de": "Qualificação", "para": "Proposta" }','{ "tarefa": "Enviar proposta", "responsavel": "vendedor@empresa", "vence_em": "D+2" }']},
   tarefa:{n:'Tarefas automáticas',steps:[['🪝','Novo negócio'],['🔎','Buscar dono'],['✏️','Completar dados'],['✅','Criar tarefa'],['🔔','Avisar vendedor']],items:['1 item','1 item','3 campos','1 tarefa','1 msg'],out:['{ "evento": "negocio_criado", "negocio_id": 5177 }','{ "dono": "vendedor@empresa", "empresa": "Empresa Ômega" }','{ "segmento": "Serviços", "origem": "Evento", "porte": "Pequeno" }','{ "tarefa": "Primeiro contato", "vence_em": "hoje" }','{ "mensagem": "Novo negócio: Empresa Ômega. Primeiro contato hoje." }']}};
  const box=el('<div class="d-col"><label class="f" for="nsel" style="max-width:320px">Workflow<select id="nsel"><option value="funil">Atualização de funil</option><option value="tarefa">Tarefas automáticas</option></select></label></div>');d.appendChild(box);
  const holder=el('<div></div>');box.appendChild(holder);box.appendChild(el('<p class="hint">Fluxos simplificados e dados fictícios. Etapas e regras reais omitidas.</p>'));
  let cv,busy=false;
  const mount=()=>{holder.innerHTML='';const f=FLOWS[q(box,'#nsel').value];cv=n8nCanvas(holder,f.n,f.steps);cv.btn.onclick=async()=>{if(busy)return;busy=true;await cv.run(f.items,f.out);busy=false;};};
  q(box,'#nsel').onchange=mount;mount();
};

/* ================= ALERTAS ================= */
DEMOS.alertas=d=>{
  const TP=[['crit','Lead sem resposta','esperando há {m} min · canal chat'],['warn','Negócio parado','{d} dias na mesma etapa'],['crit','SLA perto de vencer','vence em {s} min · motivo: sem primeiro contato'],['warn','Meta do dia em risco','{p}% da meta às {h}h'],['info','Lead quente','abriu a proposta 3 vezes hoje']];
  const C=['Empresa Alfa','Loja Beta','Clínica Gama','Escola Delta','Studio Épsilon','Mercado Zeta','Tech Eta'];
  const E=['Time SMB','Time Mid','Time Enterprise'];
  const ui=el(`<div class="app dark">${chrome('central-de-alertas · ao vivo')}<div style="padding:14px" class="d-col"><div class="bign ac"></div>
   <div class="split" style="grid-template-columns:minmax(0,1.5fr) minmax(0,1fr)"><div class="d-col" style="gap:8px"><div class="d-row" style="justify-content:space-between"><span class="muted" style="font-size:12px">● eventos simulados</span><button class="dbtn ghost pz" style="padding:5px 12px;font-size:13px">Pausar</button></div><div class="feed af"></div></div>
   <div class="d-panel"><div class="muted" style="font-size:12px;margin-bottom:8px">Meta do dia por equipe</div><div class="bars mt"></div><div class="muted" style="font-size:12px;margin:14px 0 6px">Pergunte ao agente</div><div class="qr ag"></div><div class="aga" style="font-size:13px;margin-top:8px;min-height:40px"></div></div></div></div></div>`);
  d.appendChild(ui);d.appendChild(el('<p class="hint" style="margin-top:10px">Empresas, equipes e limites fictícios. As regras reais de SLA por etapa não são exibidas.</p>'));
  const cnt={crit:0,warn:0,info:0,ok:0};const col={crit:'var(--crit)',warn:'var(--warn)',info:'var(--data)'};
  const meta={'Time SMB':52,'Time Mid':64,'Time Enterprise':41};
  const drawC=()=>{q(ui,'.ac').innerHTML='<div><b class="neg">'+cnt.crit+'</b><span>críticos</span></div><div><b class="wrn">'+cnt.warn+'</b><span>atenção</span></div><div><b style="color:var(--data)">'+cnt.info+'</b><span>oportunidades</span></div><div><b class="pos">'+cnt.ok+'</b><span>resolvidos</span></div>';
    q(ui,'.mt').innerHTML=Object.entries(meta).map(([k,v])=>'<div class="bar" style="grid-template-columns:100px 1fr 44px"><span>'+k.replace('Time ','')+'</span><div class="track"><div class="fill'+(v>=60?' best':'')+'" style="width:'+v+'%"></div></div><span class="val">'+v+'%</span></div>').join('');};
  const r=a=>a[Math.floor(Math.random()*a.length)];
  const push=()=>{const t=r(TP);const txt=t[2].replace('{m}',8+Math.floor(Math.random()*20)).replace('{d}',4+Math.floor(Math.random()*10)).replace('{s}',5+Math.floor(Math.random()*25)).replace('{p}',30+Math.floor(Math.random()*30)).replace('{h}',14+Math.floor(Math.random()*4));
    cnt[t[0]]++;const eq=r(E);if(Math.random()<.4)meta[eq]=Math.min(100,meta[eq]+1+Math.floor(Math.random()*3));drawC();const hh=new Date().toTimeString().slice(0,8);
    const a=el('<div class="alert"><i style="background:'+col[t[0]]+'"></i><div><b>'+t[1]+'</b> · '+r(C)+'<small>'+hh+' · '+eq+' · '+txt+'</small></div><button class="dbtn ghost" style="padding:4px 10px;font-size:12px;margin-right:8px">Resolver</button></div>');
    a.querySelector('button').onclick=()=>{cnt[t[0]]--;cnt.ok++;drawC();a.remove();};
    const f=q(ui,'.af');f.prepend(a);while(f.children.length>14)f.lastChild.remove();};
  drawC();for(let i=0;i<4;i++)push();
  let paused=false;T(setInterval(()=>{if(!paused)push();},1900));
  q(ui,'.pz').onclick=e=>{paused=!paused;e.target.textContent=paused?'Retomar':'Pausar';};
  const QA=[['Onde agir primeiro?',()=>'Comece pelos '+cnt.crit+' alertas críticos: leads sem resposta e SLAs perto de vencer têm o maior impacto na conversão.'],['Qual equipe está pior na meta?',()=>{const w=Object.entries(meta).sort((a,b)=>a[1]-b[1])[0];return w[0]+' está em '+w[1]+'% da meta do dia.';}],['Tenho uma ideia de alerta',()=>'Anotado! Sugestões chegam para o time de RevOps avaliar.']];
  QA.forEach(([qq,fn])=>{const b=el('<button>'+qq+'</button>');b.onclick=()=>{q(ui,'.aga').innerHTML='🤖 '+esc(fn());};q(ui,'.ag').appendChild(b);});
};

/* ================= HEALTH SCORE ================= */
DEMOS.health=d=>{
  const F=[['uso','Dias ativos nos últimos 30',0,30,v=>v/30],['adocao','Funcionalidades-chave adotadas (%)',0,100,v=>v/100],['tickets','Chamados abertos no mês',0,15,v=>1-Math.min(v,10)/10],['nps','Nota da última pesquisa (0–10)',0,10,v=>v/10],['atraso','Dias de atraso no pagamento',0,60,v=>1-Math.min(v,30)/30]];
  const W={uso:.3,adocao:.25,tickets:.15,nps:.15,atraso:.15};
  const CL=[['Empresa Alfa',[27,80,1,9,0]],['Loja Beta',[18,55,4,8,0]],['Clínica Gama',[12,40,6,6,10]],['Escola Delta',[4,15,11,4,25]],['Studio Épsilon',[22,65,2,7,3]]];
  const score=v=>Math.round(F.reduce((a,f,i)=>a+f[4](v[i])*W[f[0]]*100,0));
  const band=s=>s>=70?['Saudável','pos','var(--ok)']:s>=45?['Atenção','wrn','var(--warn)']:['Risco de churn','neg','var(--crit)'];
  const ui=el(`<div class="app dark">${chrome('carteira-cs / health-score')}<div style="display:grid;grid-template-columns:230px 1fr;min-height:360px" class="hg"><div class="cl" style="border-right:1px solid var(--line);padding:10px;display:flex;flex-direction:column;gap:4px"></div><div style="padding:14px;display:grid;grid-template-columns:1fr 200px;gap:14px" class="hd"><div class="d-col sl" style="gap:10px"></div><div style="text-align:center"><div class="gauge gg"></div><div class="gb" style="margin:8px 0"></div><div class="ga" style="font-size:13px;text-align:left"></div></div></div></div></div>`);
  d.appendChild(ui);d.appendChild(el('<p class="hint" style="margin-top:10px">Clientes fictícios e pesos ilustrativos (uso 30%, adoção 25%, suporte, NPS e financeiro 15% cada). A regra real não é exibida.</p>'));
  if(window.innerWidth<760){q(ui,'.hg').style.gridTemplateColumns='1fr';q(ui,'.hd').style.gridTemplateColumns='1fr';}
  let cur=0;
  q(ui,'.sl').innerHTML=F.map(([k,l,mn,mx])=>'<label class="f" for="h_'+k+'">'+l+': <span class="v" id="hv_'+k+'"></span><input type="range" id="h_'+k+'" min="'+mn+'" max="'+mx+'"></label>').join('');
  const list=()=>{q(ui,'.cl').innerHTML='<span class="muted mono" style="font-size:10.5px;padding:2px 6px">CARTEIRA</span>'+CL.map((c,i)=>{const s=score(c[1]),b=band(s);return '<button data-i="'+i+'" style="display:flex;justify-content:space-between;align-items:center;border:0;border-radius:8px;padding:8px;font-size:13px;text-align:left;background:'+(i===cur?'var(--panel2)':'none')+'"><span>'+c[0]+'</span><span class="pill '+b[1]+'">'+s+'</span></button>';}).join('');
    q(ui,'.cl').querySelectorAll('button').forEach(b=>b.onclick=()=>{cur=+b.dataset.i;load();});};
  const load=()=>{F.forEach(([k],i)=>q(ui,'#h_'+k).value=CL[cur][1][i]);run();};
  const run=()=>{const v=F.map(([k])=>+q(ui,'#h_'+k).value);CL[cur][1]=v;F.forEach(([k],i)=>q(ui,'#hv_'+k).textContent=v[i]);const s=score(v),b=band(s);
    q(ui,'.gg').innerHTML=gaugeSVG(s,b[2])+'<b>'+s+'</b>';q(ui,'.gb').innerHTML='<span class="pill '+b[1]+'">'+b[0]+'</span>';
    const parts=F.map((f,i)=>[f[1],f[4](v[i])]).sort((a,c)=>a[1]-c[1]);
    q(ui,'.ga').innerHTML='<span class="muted">Ponto mais fraco</span><br>'+esc(parts[0][0])+'<br><br><span class="muted">Ação sugerida</span><br>'+(s>=70?'Explorar expansão':s>=45?'Contato proativo do CS':'Plano de recuperação com o cliente');list();};
  F.forEach(([k])=>q(ui,'#h_'+k).oninput=run);load();
};
})();
