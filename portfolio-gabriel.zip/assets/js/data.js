/* ==========================================================
 DADOS DO SITE — edite aqui textos, projetos, experiências e certificados.
 Nada abaixo precisa de build: salve, faça commit e o site atualiza.
 ========================================================== */
window.SITE={};

/* Consultas do console do topo */
SITE.consultas=[
 {id:'perfil',sql:"SELECT nome, cargo_atual, cidade, anos_exp\nFROM profissionais\nWHERE github = 'gabriellima050';",
  cols:['nome','cargo_atual','cidade','anos_exp'],rows:[['Gabriel Lima Procópio','Analista de RevOps & CSOps Sr.','São Paulo','10+']]},
 {id:'impacto',sql:"SELECT entrega, resultado\nFROM impacto\nORDER BY relevancia DESC\nLIMIT 5;",
  cols:['entrega','resultado'],rows:[['Estratégias de retenção com análise preditiva','~50% menos churn'],['Health Score em tempo real','criado do zero'],['Relatórios em Power BI automatizados','+12 h/mês livres'],['TáVindo.AI (MVP)','50+ usuários · 300 buscas'],['Reconhecimento por valores da empresa','7x destaque']]},
 {id:'stack',sql:"SELECT categoria,\n       STRING_AGG(ferramenta, ' · ') AS ferramentas\nFROM stack\nGROUP BY categoria;",
  cols:['categoria','ferramentas'],rows:[['dados','SQL · Databricks · BigQuery · Redshift · SAS'],['bi','Power BI · HEX · QlikView · Looker'],['automação & ia','n8n · Apps Script · Python · LLMs'],['web','React · Next · FastAPI · Flask'],['crm','HubSpot · APIs de atendimento']]},
 {id:'agora',sql:"SELECT empresa, cargo, desde\nFROM trajetoria\nWHERE fim IS NULL;",
  cols:['empresa','cargo','desde'],rows:[['Octadesk','Analista de RevOps & CSOps Sênior','mai/2026']]}
];

/* Projetos: vis "priv" (privado/anonimizado) ou "pub" (público, com repo).
   feat:1 deixa o card largo. pv define a prévia do card. tags: ia | auto | dados */
SITE.projetos=[
 {id:'tavindo',feat:1,pv:'chat',c:'#00C3A5',vis:'priv',cat:'IA · Produto próprio',title:'TáVindo.AI',sub:'Agente de IA no WhatsApp que avisa quando o ônibus passa e informa o status do metrô e da CPTM em São Paulo.',
  stack:['n8n','Evolution API','LLMs','Google Maps API','SPTrans API','React','Supabase'],skills:['n8n','LLMs','React','TypeScript','Supabase','WhatsApp API'],tags:['ia','auto'],
  built:['Agente no WhatsApp: o n8n identifica a intenção e direciona para o fluxo de ônibus ou de metrô','Modelo matemático próprio para corrigir a previsão de chegada (curvas, semáforos, trajeto real)','Landing page e painel admin com usuários, cobrança, reengajamento e analytics','Testes com Grok, Gemini e GPT-4 mini até chegar ao modelo final'],
  result:'MVP de 3 meses com 50+ usuários ativos e 300 buscas. Encerrado em dez/2025.',note:'Projeto próprio (build in public). Repositórios privados: tavindoai-bolt e ta-vindo-ai.',hint:'mensagens de exemplo iguais às da landing original'},
 {id:'alertas',pv:'feed',c:'#ff5d6c',vis:'priv',cat:'RevOps · Tempo real',title:'Central de alertas de funil',sub:'O funil comercial deixa de depender do relatório do mês passado e passa a avisar onde agir, na hora.',
  stack:['Airflow','Kubernetes','MongoDB','FastAPI','React','APIs de CRM'],skills:['Airflow','Kubernetes','MongoDB','FastAPI','React','HubSpot','LLMs','Python'],tags:['auto','dados','ia'],
  built:['Unificação de CRM e plataforma de atendimento em uma base única','Alertas com motivo: lead sem resposta, negócio parado, SLA perto de vencer','Painel ao vivo e acompanhamento de meta por equipe','Agente de IA que tira dúvidas e recebe sugestões dos usuários'],
  result:'Time comercial agindo na hora, em vez de descobrir o problema depois.',note:'Projeto corporativo, construído com um parceiro de tecnologia. Empresa, regras de SLA e dados reais omitidos.',hint:'eventos simulados chegando ao vivo'},
 {id:'hub',feat:1,pv:'bars',c:'#7aa2ff',vis:'priv',cat:'BI · Plataforma interna',title:'Portal central de dashboards',sub:'Plataforma interna que reúne os dashboards da empresa com permissão por usuário. Dispensou o uso de Tableau ou Power BI.',
  stack:['Next.js','React','SQL','APIs externas','IA'],skills:['Next.js','React','SQL','Databricks','LLMs'],tags:['dados','ia'],
  built:['Todos os dashboards em um só lugar, conectados ao banco e a APIs externas','Permissionamento por usuário: cada pessoa vê só o que foi liberado','Score de negociações a partir de análise de sentimento dos resumos de reunião','Construído com vibe coding'],
  result:'Sem custo de licença de ferramenta de BI e com controle de acesso fino.',note:'Projeto corporativo. Empresa, dashboards reais e usuários omitidos; perfis e números da demo são fictícios.',hint:'troque de usuário e edite as permissões'},
 {id:'dedup',pv:'form',c:'#f2b544',vis:'priv',cat:'CRM · Qualidade de dados',title:'Cadastro de leads sem duplicidade',sub:'Vendedores sobem leads no CRM por aqui. O sistema barra duplicados e manda os casos duvidosos para aprovação de RevOps.',
  stack:['Next.js','React','API do CRM','TypeScript'],skills:['Next.js','React','HubSpot','TypeScript'],tags:['dados'],
  built:['Bloqueio quando o telefone ou o e-mail já existe na base','Busca por aproximação de nome nos contatos já cadastrados','Caso duvidoso vira um card para RevOps aprovar ou recusar','Lead novo e sem conflito é criado direto no CRM'],
  result:'Vendedor sobe lead sozinho e a base continua limpa.',note:'Projeto corporativo. Nome da empresa, limites reais de similaridade e dados omitidos.',hint:'use os atalhos para testar cada caso'},
 {id:'radar',pv:'flow',c:'#ff6d5a',vis:'priv',cat:'Automação · Prospecção',title:'Radar de notícias de prospecção',sub:'Fluxo no n8n que funciona quase como um agente outbound: procura notícias de empresas ligadas ao ICP e avisa o time comercial.',
  stack:['n8n','Busca de notícias','LLMs','Chat do time'],skills:['n8n','LLMs'],tags:['auto','ia'],
  built:['Busca recorrente por palavras-chave e notícias sobre possíveis clientes','Sinais de compra: venda de empresas, abertura de capital, captação, expansão','Filtro pelo perfil de cliente ideal (ICP) e resumo com IA','Entrega no canal do time comercial com o motivo do alerta'],
  result:'O time aborda a empresa no momento em que ela tem um motivo para comprar.',note:'Projeto corporativo. Empresa, ICP real, fontes e palavras-chave omitidos.',hint:'escolha ICP e sinais, depois execute o fluxo'},
 {id:'n8n',pv:'flow',c:'#ff9f43',vis:'priv',cat:'Automação',title:'Automações de funil no n8n',sub:'Fluxos que preenchem propriedades, mudam status, avançam etapas e criam tarefas no CRM sem trabalho manual.',
  stack:['n8n','API do CRM','Webhooks'],skills:['n8n','HubSpot'],tags:['auto'],
  built:['Atualização automática de etapas e propriedades do funil','Criação de tarefas e registros sem trabalho manual do vendedor','Gatilhos por eventos do CRM via webhook'],
  result:'Menos tempo preenchendo CRM, mais tempo gerando receita.',note:'Projeto corporativo. Empresa e regras de etapa omitidas.',hint:'escolha um fluxo e execute'},
 {id:'health',pv:'gauge',c:'#4fd18b',vis:'priv',cat:'CS Ops · Retenção',title:'Health Score de clientes',sub:'Indicador de saúde do cliente em tempo real, usado para antecipar churn e orientar o time de CS.',
  stack:['SQL','Power BI','Análise preditiva'],skills:['SQL','Power BI','Storytelling com dados'],tags:['dados'],
  built:['Sinais de uso, adoção, suporte e financeiro combinados em um único score','Faixas de risco que viram ação para o time de Customer Success','Estudos de adoção, First Value e correlação com churn'],
  result:'Parte das estratégias que levaram a ~50% de redução de churn.',note:'Projeto corporativo. Pesos, variáveis reais e empresa omitidos; pesos da demo são ilustrativos.',hint:'mexa nos sinais do cliente'},
 {id:'sentimento',feat:1,pv:'sheet',c:'#0f9d58',vis:'pub',repo:'AnaliseSentimento_GoogleSheets',cat:'IA · Google Sheets',title:'Analisador de sentimentos no Sheets',sub:'Menu no Google Sheets que classifica feedbacks de clientes com IA e cria uma aba de resumo com big numbers.',
  stack:['Google Apps Script','Groq · Llama 3','Google Sheets'],skills:['Google Apps Script','Groq / Llama 3','LLMs'],tags:['ia'],
  built:['Menu “✉️ Analisar Sentimentos” criado no onOpen','Prompt que exige a saída sentimento|confiança|categoria|emoção|palavras','Preenchimento automático das 5 colunas por linha','Aba “Resumo Sentimentos” com total, positivos, negativos, neutros e taxa de satisfação'],result:'Feedback qualitativo vira indicador sem sair da planilha.',hint:'edite as respostas na coluna A e rode pelo menu'},
 {id:'queries',pv:'sheet',c:'#1a73e8',vis:'pub',repo:'Documentacao_IA_GoogleSheets',cat:'IA · Documentação',title:'Assistente de scripts com IA',sub:'Cataloga os scripts de uma pasta do Drive com descrições geradas por IA e responde perguntas num chat dentro do Sheets.',
  stack:['Google Apps Script','HTML Service','Groq · Llama 3','Google Drive'],skills:['Google Apps Script','Groq / Llama 3','SQL','LLMs'],tags:['ia','auto'],
  built:['Leitura recursiva da pasta e subpastas do Drive (.sql, .txt, .py, .js, .gs, .html)','Descrição em linguagem simples gerada pela IA para cada arquivo','Aba “Catalogo” com nome, descrição, link e data','Chat em HTML que filtra o catálogo e devolve os scripts relevantes'],result:'O conhecimento técnico do time fica documentado e pesquisável.',hint:'atualize o catálogo e depois abra o chat'},
 {id:'chat',pv:'chat',c:'#764ba2',vis:'pub',repo:'ChatIA_HTML_Python',cat:'IA · Web',title:'Chat IA com Flask',sub:'Interface de chat em HTML, CSS e JS puros, com backend Flask conectado a um LLM.',
  stack:['Python','Flask','HTML/CSS/JS','Groq · Llama 3'],skills:['Python','Flask','LLMs','Groq / Llama 3'],tags:['ia'],
  built:['Interface com animações, status online e indicador de digitação','Exportação do histórico em .txt e botão de limpar conversa','Backend Flask que repassa as mensagens à API do modelo'],result:'Base simples para integrar IA a qualquer interface web.',hint:'visual igual ao do repositório'},
 {id:'precos',pv:'bars',c:'#ff4b4b',vis:'pub',repo:'Comparador_Precos_Python',cat:'Dados · Web scraping',title:'Comparador de preços',sub:'App em Streamlit que busca um produto em várias lojas, limpa os preços e recomenda onde comprar.',
  stack:['Python','Streamlit','BeautifulSoup','Pandas','Plotly'],skills:['Python','Streamlit'],tags:['dados'],
  built:['Busca em Mercado Livre, Buscapé, Google Shopping e Zoom com rotação de user-agents','Limpeza de preços com expressões regulares','Gráfico interativo, métricas e recomendação por faixa de economia','Modo de demonstração quando os sites bloqueiam robôs'],result:'Do HTML bagunçado a uma recomendação de compra.',hint:'preços simulados, como no modo demo do app'},
 {id:'agenda',pv:'term',c:'#f2b544',vis:'pub',repo:'Exporta_Query_Envia_Email_Python',cat:'Automação · BI',title:'Query agendada por e-mail',sub:'Script que roda uma query no Redshift, salva o resultado em Excel e envia por e-mail em horários fixos.',
  stack:['Python','Redshift','Pandas','yagmail','schedule'],skills:['Python','Redshift','SQL','Excel'],tags:['auto','dados'],
  built:['Conexão com Redshift via psycopg2','Exportação para .xlsx com nome datado','Envio com anexo via yagmail','Agendamento diário com schedule e loop de verificação'],result:'O relatório diário chega sozinho na caixa de entrada.',hint:'acelere o relógio e veja os disparos'},
 {id:'resumo',pv:'term',c:'#c39bff',vis:'pub',repo:'Leitura_Excel_IA_Python',cat:'IA · Dados',title:'Resumo de Excel com IA',sub:'Lê centenas de observações de clientes num Excel e devolve um resumo final objetivo.',
  stack:['Python','Pandas','Groq · Llama 3'],skills:['Python','Groq / Llama 3','Excel','LLMs'],tags:['ia','dados'],
  built:['Limpeza de células vazias da coluna Observação','Texto quebrado em blocos de até 15 mil caracteres (~3.750 tokens)','Um resumo parcial por bloco e um resumo final a partir deles'],result:'Horas de leitura de chamados viram um parágrafo.',hint:'ajuste o tamanho do bloco e rode'},
 {id:'email',pv:'sheet',c:'#0a7fcb',vis:'pub',repo:'Dispara_Email_GoogleSheets',cat:'Automação · CS',title:'Disparo de e-mail pelo Sheets',sub:'Menu na planilha que envia uma pesquisa de satisfação personalizada após o atendimento e marca o status.',
  stack:['Google Apps Script','GmailApp','Google Sheets'],skills:['Google Apps Script'],tags:['auto'],
  built:['Menu “✉️ Disparo E-mail” com caixa para digitar o e-mail do cliente','Busca do cliente na planilha e bloqueio de reenvio','E-mail HTML com nome do cliente, do atendente e botão para a pesquisa','Status “Enviado” ou “Erro no envio” gravado na coluna E'],result:'Pesquisa de satisfação disparada sem sair da planilha.',hint:'use o menu como no Sheets'}
];

/* Stack: grupos e ferramentas (os nomes ligam com "skills" dos projetos) */
SITE.stack={
 'Dados':['SQL','Databricks','BigQuery','Redshift','SQL Server','MySQL','SAS'],
 'BI & Visualização':['Power BI','HEX','QlikView','Looker','Excel','Storytelling com dados'],
 'Automação & IA':['n8n','Google Apps Script','Python','LLMs','Groq / Llama 3','Airflow'],
 'Web & Produto':['React','Next.js','TypeScript','FastAPI','Flask','Streamlit','Supabase'],
 'CRM & Operação':['HubSpot','WhatsApp API','Kubernetes','MongoDB']
};

/* Trajetória (s/e = ano decimal: 2025.58 ≈ ago/2025). cls: now | side | edu */
SITE.trajetoria=[
 {id:'octa',org:'Octadesk',role:'Analista de RevOps & CSOps Sênior',s:2026.33,e:null,cls:'now',period:'mai/2026 – atual',loc:'São Paulo',pts:['Revenue Operations e CS Ops para os times comercial e de Customer Success','Gestão do funil com alertas em tempo real, unindo CRM e plataforma de atendimento','Análises de uso da plataforma, churn e saúde da carteira']},
 {id:'jera',org:'Jera Capital',role:'Analista de Dados Sênior · RevOps, Automação e Marketing',s:2025.58,e:2026.33,period:'ago/2025 – mai/2026 · 10 meses',loc:'São Paulo · Híbrido',pts:['Consultas SQL no Databricks e dashboards na HEX para inteligência comercial','Apresentações executivas para a diretoria','Gestão do funil no HubSpot, boas práticas de CRM e cadência comercial','Portal interno de dashboards com permissão por usuário, cadastro de leads sem duplicidade e radar de notícias de prospecção','Automações de funil com n8n']},
 {id:'tv',org:'TáVindo.AI',role:'Founder · projeto próprio',s:2025,e:2025.95,cls:'side',period:'jan/2025 – dez/2025',loc:'Remoto',pts:['Agente no WhatsApp com informações em tempo real do transporte público de SP','Orquestração com n8n, integrações com APIs e uso de LLMs para entender pedidos','50+ usuários ativos e 300 buscas em 3 meses de MVP']},
 {id:'omie',org:'Omie',role:'Especialista em Dados · RevOps & CSOps',s:2021.67,e:2025.5,period:'set/2021 – jul/2025 · ~4 anos',loc:'São Paulo · Híbrido',pts:['Redução de ~50% no churn com estratégias baseadas em análises preditivas','Criação do Health Score para monitorar a saúde do cliente em tempo real','Estudos de First Value, adoção, usabilidade, precificação e correlação com churn','Antes, em Serviços Bancários: dashboards do zero e +12 h/mês economizadas com automação','7x destaque por valores (2022–2024), Option Holder e programa Acelera Líderes']},
 {id:'neo',org:'Neobpo',role:'Analista de BI e MIS Sênior · Planejamento Sênior',s:2019.42,e:2021.67,period:'jun/2019 – ago/2021 · 2 anos 3 meses',loc:'São Paulo',pts:['Indicadores e KPIs em Power BI para operações de call center','Bases em SQL Server e relatórios em Excel','Planejamento para conta do setor bancário com rotinas em SAS']},
 {id:'vik',org:'Vikstar Contact Center',role:'Analista de Indicadores B2B · Customer Success',s:2017.67,e:2019.42,period:'set/2017 – jun/2019 · 1 ano 10 meses',loc:'São Paulo',pts:['Indicadores de CS para operação B2B de telecom','Cruzamento de bases em SQL, Power BI e análises de satisfação do cliente']},
 {id:'dnr',org:'Grupo DNR',role:'Analista de MIS Pleno',s:2016.67,e:2017.67,period:'set/2016 – ago/2017',loc:'São Paulo',pts:['Relatórios via SQL, jobs e procedures','MySQL e Reporting Services','Apresentação de comitês para clientes']},
 {id:'tro',org:'Tróchia',role:'Planejamento Estratégico',s:2016.08,e:2016.67,period:'fev/2016 – set/2016',loc:'São Paulo',pts:['Relatórios de BI e extração via SQL','Coordenação de equipe e relação com assessorias parceiras','Régua de cobrança e estratégias operacionais']},
 {id:'rb',org:'R Brasil Soluções',role:'Operador de Cobrança → Auxiliar → Assistente de MIS',s:2013.58,e:2016.08,period:'ago/2013 – fev/2016 · 2 anos 7 meses',loc:'São Paulo',pts:['Início na operação de cobrança de cartões','Migração para MIS: indicadores, SQL Server e QlikView','Onde a carreira em dados começou']},
 {id:'uni',org:'Uninove',role:'Formação acadêmica',s:2015,e:2018.95,cls:'edu',period:'2015 – 2018',loc:'São Paulo',pts:['Universidade Nove de Julho']}
];

/* Certificados [título, emissor · ano] */
SITE.certificados=[['Academy Accreditation · Databricks Fundamentals','Databricks · 2025'],['Business Intelligence Foundation Professional (BIFPC)','CertiProf · 2024'],['Excelência em Experiência do Cliente','Reclame AQUI · 2024'],['Acelera Líderes','Omie · 2024'],['Microsoft Power BI para BI e Data Science','Data Science Academy · 2024'],['Customer Success: como conquistar e manter clientes','Sebrae · 2024'],['Storytelling com Dados para Comunicação Profissional','Enap · 2024'],['Lifelong Learning','CertiProf · 2024'],['Formação em Liderança','Escola Conquer · 2023']];
