(function(){
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
window.__U={$,esc,reduce};

/* ================= HERO CONSOLE ================= */
const QUERIES=SITE.consultas;
function hl(sql){
  return esc(sql).replace(/'[^']*'/g,m=>'<span class="str">'+m+'</span>')
   .replace(/\b(SELECT|FROM|WHERE|ORDER BY|DESC|LIMIT|GROUP BY|AS|IS NULL|STRING_AGG)\b/g,'<span class="kw">$1</span>')
   .replace(/\b(\d+)\b/g,'<span class="num">$1</span>');
}
let qi=0,typing=null;
const qtabs=$('#qtabs');
QUERIES.forEach((q,i)=>{const b=document.createElement('button');b.className='qtab';b.setAttribute('role','tab');b.textContent=q.id+'.sql';b.setAttribute('aria-selected',i===0);b.onclick=()=>{qi=i;[...qtabs.children].forEach((c,j)=>c.setAttribute('aria-selected',j===i));runQuery();};qtabs.appendChild(b);});
function renderResult(q,ms){
  $('#result').innerHTML='<table class="grid"><thead><tr>'+q.cols.map(c=>'<th>'+c+'</th>').join('')+'</tr></thead><tbody>'+q.rows.map((r,i)=>'<tr style="animation-delay:'+(i*70)+'ms">'+r.map(c=>'<td>'+esc(c)+'</td>').join('')+'</tr>').join('')+'</tbody></table>';
  $('#rstatus').textContent=q.rows.length+(q.rows.length>1?' linhas':' linha')+' · '+ms+' ms';
}
function runQuery(){
  const q=QUERIES[qi];clearInterval(typing);
  $('#result').innerHTML='';$('#rstatus').textContent='digitando…';
  if(reduce){$('#editor').innerHTML=hl(q.sql);renderResult(q,38);return;}
  let n=0;
  typing=setInterval(()=>{n+=2;$('#editor').innerHTML=hl(q.sql.slice(0,n))+'<span class="caret"></span>';
    if(n>=q.sql.length){clearInterval(typing);$('#editor').innerHTML=hl(q.sql);$('#rstatus').textContent='executando…';setTimeout(()=>renderResult(q,20+Math.floor(Math.random()*40)),380);}
  },18);
}
$('#runBtn').onclick=runQuery;
runQuery();

/* ================= PROJECTS ================= */
const P=SITE.projetos;
window.__P=P;
const FILTERS=[['todos','Todos'],['ia','IA'],['auto','Automação'],['dados','Dados & BI']];
let filter='todos',activeSkill=null;
const fwrap=$('#filters');
FILTERS.forEach(([k,l])=>{const b=document.createElement('button');b.className='chip';b.textContent=l;b.setAttribute('aria-pressed',k===filter);b.onclick=()=>{filter=k;[...fwrap.children].forEach(c=>c.setAttribute('aria-pressed',c===b));renderCards();};fwrap.appendChild(b);});

const PV={
 tavindo:()=>'<div class="mini wa"><div class="mh"><span class="av">TV</span><b>TáVindo.AI</b><small>Online agora</small></div><div class="mb"><span class="b me">875A-10 Rua Augusta</span><span class="b">O 875A-10 passará em 3 minutos na Rua Augusta</span><span class="b me">Linha 4-Amarela</span><span class="b">Linha 4-Amarela operando normalmente</span></div></div>',
 alertas:()=>'<div class="mini list">'+[['var(--crit)','Lead sem resposta','esperando há 12 min'],['var(--warn)','Negócio parado','6 dias na mesma etapa'],['var(--crit)','SLA perto de vencer','vence em 9 min']].map(a=>'<div class="row" style="border-left-color:'+a[0]+'"><b>'+a[1]+'</b><small>'+a[2]+'</small></div>').join('')+'</div>',
 hub:()=>'<div class="mini dash"><div class="side"><b>▦ Portal</b><span class="on">Funil comercial</span><span>Metas</span><span>Carteira &amp; churn</span><span>🔒 4 sem acesso</span></div><div class="main"><div class="kp"><div><b>163</b><small>negócios</small></div><div><b>21%</b><small>conversão</small></div><div><b>18d</b><small>ciclo</small></div></div><svg viewBox="0 0 200 50" preserveAspectRatio="none"><polygon points="0,50 0,38 28,30 57,33 85,24 114,20 142,22 171,12 200,8 200,50" fill="color-mix(in srgb,var(--data) 22%,transparent)"/><polyline points="0,38 28,30 57,33 85,24 114,20 142,22 171,12 200,8" fill="none" stroke="var(--data)" stroke-width="2"/></svg></div></div>',
 dedup:()=>'<div class="mini list">'+[['var(--crit)','maria.souza@alfa.com','Cadastro barrado · e-mail já existe'],['var(--warn)','Ana Lucia Reiss','92% parecido · enviado para RevOps'],['var(--ok)','Rafael Torres','Lead criado no CRM']].map(a=>'<div class="row" style="border-left-color:'+a[0]+'"><b>'+a[1]+'</b><small>'+a[2]+'</small></div>').join('')+'</div>',
 radar:()=>flow([['⏰','Agenda'],['📰','Notícias'],['🎯','ICP'],['🧠','IA'],['💬','Time']],'6 alertas de compra enviados'),
 n8n:()=>flow([['🪝','Webhook'],['🔀','IF etapa'],['✏️','Propriedades'],['✅','Tarefa']],'Negócio movido para Proposta'),
 health:()=>'<div class="mini gauge2"><svg viewBox="0 0 200 110"><path d="M25 100 A75 75 0 0 1 175 100" fill="none" stroke="var(--line)" stroke-width="16" stroke-linecap="round"/><path d="M25 100 A75 75 0 0 1 160 56" fill="none" stroke="var(--ok)" stroke-width="16" stroke-linecap="round"/><text x="100" y="96" text-anchor="middle" font-size="34" font-weight="800" fill="var(--text)" font-family="Bricolage Grotesque, sans-serif">82</text></svg><div><span class="pill pos">Saudável</span><small>Empresa Alfa · uso 27/30 dias</small><span class="pill neg">Risco</span><small>Escola Delta · 25 dias de atraso</small></div></div>',
 sentimento:()=>sheet(['Resposta do Cliente','Sentimento','Confiança'],[['Atendimento excelente!','positivo','0.92'],['O sistema travou hoje','negativo','0.83'],['Seria bom ter relatório','neutro','0.61']],1),
 queries:()=>sheet(['Nome do Arquivo','Descrição do Script'],[['clientes_sem_login_30d.sql','Lista clientes sem acesso há 30 dias'],['funil_conversao.sql','Conversão entre etapas do funil'],['nps_por_segmento.sql','NPS por segmento de cliente']]),
 chat:()=>'<div class="mini gchat"><div class="mh">🤖 <b>AI Assistant - Groq</b> <small>● Online</small></div><div class="mb"><span class="b me">O que é churn?</span><span class="b">Churn é a taxa de clientes que cancelam em um período.</span></div></div>',
 precos:()=>{const d=[['Magalu',1321,'#0086ff'],['M. Livre',1506,'#ffe600'],['C. Bahia',1521,'#0033a0'],['Amazon',1552,'#ff9900']];return '<div class="mini st"><b>🛒 Comparador de Preços</b><div class="bars2">'+d.map(x=>'<div><span style="height:'+(x[1]/1552*58)+'px;background:'+x[2]+'"></span><small>'+x[0]+'</small></div>').join('')+'</div><div class="rec">🟢 Economize 14,9% no Magalu</div></div>';},
 agenda:()=>term(['🕒 Script agendado para rodar diariamente às 11:00 e 16:30.','<span class="m"># pd.read_sql_query → 1.284 linhas</span>','<span class="p">✅ Relatório enviado com sucesso às 11:00!</span>']),
 resumo:()=>term(['▶️ Resumindo parte 1/3...','▶️ Resumindo parte 2/3...','▶️ Resumindo parte 3/3...','<span class="p">✅ RESUMO FINAL DAS OBSERVAÇÕES:</span>']),
 email:()=>sheet(['Nome do cliente','Nome do Atendente','Status do envio'],[['Ana Ribeiro','Carla','Enviado'],['Bruno Matos','Diego','Enviado'],['Clara Nunes','Carla','']],2)
};
function flow(n,res){return '<div class="mini n8"><div class="nf">'+n.map((x,i)=>(i?'<i></i>':'')+'<div><span>'+x[0]+'</span><small>'+x[1]+'</small></div>').join('')+'</div><div class="res">✓ '+res+'</div></div>';}
function sheet(h,rows,colorCol){return '<div class="mini sh"><table><tr>'+h.map(x=>'<th>'+x+'</th>').join('')+'</tr>'+rows.map(r=>'<tr>'+r.map((c,i)=>'<td class="'+(i===colorCol?({positivo:'pos',negativo:'neg',neutro:'neu',Enviado:'pos'}[c]||''):'')+'">'+c+'</td>').join('')+'</tr>').join('')+'</table></div>';}
function term(lines){return '<div class="mini tm">'+lines.map(l=>'<div>'+l+'</div>').join('')+'</div>';}
function preview(p){return '<div class="pv" style="--c:'+p.c+'" aria-hidden="true">'+(PV[p.id]?PV[p.id]():'')+'</div>';}

function renderCards(){
  ['priv','pub'].forEach(v=>{
    const g=$('#pgrid-'+v);g.innerHTML='';
    const list=P.filter(p=>p.vis===v&&(filter==='todos'||p.tags.includes(filter)));
    $('#sh-'+v).style.display=list.length?'':'none';
    list.forEach(p=>{
      const b=document.createElement('button');b.className='card'+(p.feat?' feat':'')+(activeSkill&&!p.skills.includes(activeSkill)?' dim':'');
      b.innerHTML=preview(p)+'<div class="cbody"><div class="top"><span class="cat">'+esc(p.cat)+'</span><span class="vis '+p.vis+'">'+(p.vis==='pub'?'● público':'◆ privado')+'</span></div><h3>'+esc(p.title)+'</h3><p>'+esc(p.sub)+'</p><div class="stk">'+p.stack.slice(0,p.feat?7:4).map(s=>'<span>'+esc(s)+'</span>').join('')+'</div><span class="open">Abrir demo →</span></div>';
      b.onclick=()=>openModal(p);g.appendChild(b);
    });
  });
}

/* ================= STACK ================= */
const STACK=SITE.stack;
const sg=$('#stackGrid');
Object.entries(STACK).forEach(([g,items])=>{
  const d=document.createElement('div');d.className='stackgroup';
  d.innerHTML='<h3>'+g+'</h3><div class="chips">'+items.map(s=>'<button class="chip" aria-pressed="false" data-skill="'+esc(s)+'">'+esc(s)+'</button>').join('')+'</div>';
  sg.appendChild(d);
});
sg.addEventListener('click',e=>{const b=e.target.closest('[data-skill]');if(!b)return;const s=b.dataset.skill;activeSkill=activeSkill===s?null:s;applySkill();if(activeSkill)document.getElementById('projetos').scrollIntoView({behavior:reduce?'auto':'smooth'});});
$('#clearSkill').onclick=()=>{activeSkill=null;applySkill();};
function applySkill(){sg.querySelectorAll('[data-skill]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.skill===activeSkill));$('#clearSkill').hidden=!activeSkill;renderCards();}
renderCards();

/* ================= MODAL ================= */
let cleanup=[];
window.__addTimer=id=>{cleanup.push(()=>{clearInterval(id);clearTimeout(id);});return id;};
function openModal(p){
  $('#mcat').textContent=p.cat+' · '+(p.vis==='pub'?'repositório público':'projeto privado');
  $('#mtitle').textContent=p.title;$('#msub').textContent=p.sub;$('#mhint').textContent=p.hint||'';
  $('#minfo').innerHTML='<h4>O que foi construído</h4><ul>'+p.built.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ul><h4>Resultado</h4><p style="margin:0">'+esc(p.result)+'</p><h4>Stack</h4><div class="chips">'+p.stack.map(s=>'<span class="chip">'+esc(s)+'</span>').join('')+'</div>'+(p.repo?'<p style="margin:18px 0 0"><a href="https://github.com/gabriellima050/'+p.repo+'">Ver código no GitHub →</a></p>':'')+(p.note?'<div class="note">'+esc(p.note)+'</div>':'');
  const d=$('#mdemo');d.innerHTML='';
  try{(window.DEMOS[p.id]||(()=>{}))(d);}catch(err){d.innerHTML='<div class="d-panel neg">Não foi possível carregar esta demo.</div>';console.error(err);}
  $('#modal').classList.add('open');document.body.style.overflow='hidden';$('#modal').scrollTop=0;$('#mclose').focus();
}
function closeModal(){cleanup.forEach(f=>f());cleanup=[];$('#modal').classList.remove('open');document.body.style.overflow='';$('#mdemo').innerHTML='';}
$('#mclose').onclick=closeModal;
$('#modal').addEventListener('click',e=>{if(e.target.id==='modal')closeModal();});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('#modal').classList.contains('open'))closeModal();});

/* ================= GANTT ================= */
const _n=new Date();const Y0=2013,Y1=_n.getFullYear()+_n.getMonth()/12+0.08;
SITE.trajetoria.forEach(g=>{if(g.e==null)g.e=Y1;});
const G=SITE.trajetoria;
const gEl=$('#gantt');const span=Y1-Y0;
let ticks='';for(let y=Y0;y<=2026;y++)ticks+='<span style="left:'+((y-Y0)/span*100)+'%">'+(y===Y0||y%2===0||y===2026?y:'')+'</span>';
const grid='background-image:linear-gradient(90deg,color-mix(in srgb,var(--line) 50%,transparent) 1px,transparent 1px);background-size:'+(100/span)+'% 100%';
gEl.innerHTML='<div class="gaxis"><div></div><div class="ticks">'+ticks+'</div></div>'+G.map(g=>'<div class="grow"><div class="lbl">'+esc(g.org)+'<small>'+esc(g.period.split(' · ')[0])+'</small></div><div class="lane" style="'+grid+'"><button class="gbar '+(g.cls||'')+'" data-g="'+g.id+'" aria-pressed="false" aria-label="'+esc(g.org+': '+g.role)+'" style="left:'+((g.s-Y0)/span*100)+'%;width:'+((g.e-g.s)/span*100)+'%"></button></div></div>').join('');
function showG(id){const g=G.find(x=>x.id===id);gEl.querySelectorAll('.gbar').forEach(b=>b.setAttribute('aria-pressed',b.dataset.g===id));
  $('#gdetail').innerHTML='<div><span class="tag">'+esc(g.period)+'</span><h3>'+esc(g.org)+'</h3><p style="margin:6px 0 0">'+esc(g.role)+'</p><p class="muted" style="margin:4px 0 0;font-size:14px">'+esc(g.loc)+'</p></div><ul>'+g.pts.map(p=>'<li>'+esc(p)+'</li>').join('')+'</ul>';}
gEl.addEventListener('click',e=>{const b=e.target.closest('[data-g]');if(b)showG(b.dataset.g);});
showG('octa');

/* ================= CERTS ================= */
const CERTS=SITE.certificados;
$('#certs').innerHTML=CERTS.map(c=>'<div class="cert"><b>'+esc(c[0])+'</b><span>'+esc(c[1])+'</span></div>').join('');
})();
